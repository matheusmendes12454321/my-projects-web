<?php
// notas.php
require_once 'config.php';
verificarLogin();

$conn = conectarBanco();
$ordem_id = $_GET['ordem'] ?? 0;

// Buscar dados da ordem
$query = "
    SELECT os.*, 
           c.nome as cliente_nome,
           c.cpf_cnpj as cliente_cpf_cnpj,
           c.telefone as cliente_telefone,
           c.email as cliente_email,
           c.endereco as cliente_endereco,
           c.tipo as cliente_tipo,
           tp.nome as pagamento_nome
    FROM ordens_servico os
    LEFT JOIN clientes c ON os.cliente_id = c.id
    LEFT JOIN tipos_pagamento tp ON os.tipo_pagamento_id = tp.id
    WHERE os.id = ?
";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $ordem_id);
$stmt->execute();
$ordem = $stmt->get_result()->fetch_assoc();

if (!$ordem) {
    die("Ordem não encontrada!");
}

// Buscar itens da ordem
$itens = $conn->query("
    SELECT oi.*, s.nome as servico_nome
    FROM ordem_itens oi
    JOIN servicos s ON oi.servico_id = s.id
    WHERE oi.ordem_id = $ordem_id
");
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Nota de Serviço - Copiadora Central</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        @media print {
            .no-print {
                display: none !important;
            }
            body {
                font-size: 12px;
            }
            .container {
                width: 100%;
                max-width: none;
            }
        }
        .nota-container {
            border: 2px solid #000;
            padding: 20px;
            margin: 20px auto;
            max-width: 800px;
        }
        .empresa-header {
            text-align: center;
            border-bottom: 2px solid #000;
            padding-bottom: 15px;
            margin-bottom: 20px;
        }
        .empresa-header h2 {
            margin: 0;
            font-weight: bold;
        }
        .empresa-header p {
            margin: 5px 0;
        }
        .detalhes-cliente {
            margin-bottom: 20px;
        }
        .detalhes-ordem {
            margin-bottom: 20px;
        }
        .table-nota {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        .table-nota th,
        .table-nota td {
            border: 1px solid #000;
            padding: 8px;
            text-align: left;
        }
        .table-nota th {
            background-color: #f8f9fa;
        }
        .total-box {
            text-align: right;
            margin-top: 20px;
        }
        .assinatura {
            margin-top: 50px;
            border-top: 1px solid #000;
            padding-top: 10px;
            text-align: center;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="no-print text-center mb-3">
            <button onclick="window.print()" class="btn btn-primary me-2">
                <i class="bi bi-printer"></i> Imprimir Nota
            </button>
            <a href="ordens.php" class="btn btn-secondary">
                <i class="bi bi-arrow-left"></i> Voltar
            </a>
            <?php if ($ordem['status_pagamento'] === 'pendente'): ?>
                <button onclick="marcarComoPago()" class="btn btn-success">
                    <i class="bi bi-check-circle"></i> Marcar como Pago
                </button>
            <?php endif; ?>
        </div>
        
        <div class="nota-container">
            <!-- Cabeçalho da Empresa -->
            <div class="empresa-header">
                <h2><?php echo EMPRESA_NOME; ?></h2>
                <p>CNPJ: <?php echo EMPRESA_CNPJ; ?></p>
                <p><?php echo EMPRESA_ENDERECO; ?> - <?php echo EMPRESA_CIDADE; ?></p>
                <p>Telefone: <?php echo EMPRESA_TELEFONE; ?> | E-mail: <?php echo EMPRESA_EMAIL; ?></p>
            </div>
            
            <!-- Informações da Ordem -->
            <div class="detalhes-ordem row">
                <div class="col-md-6">
                    <p><strong>NOTA DE SERVIÇO #<?php echo str_pad($ordem['id'], 6, '0', STR_PAD_LEFT); ?></strong></p>
                    <p><strong>Data da Ordem:</strong> <?php echo formatarData($ordem['data_ordem'], 'd/m/Y H:i'); ?></p>
                    <p><strong>Data de Entrega:</strong> <?php echo formatarData($ordem['data_entrega']); ?></p>
                </div>
                <div class="col-md-6">
                    <p><strong>Status:</strong> 
                        <span class="badge bg-<?php echo $ordem['status_pagamento'] === 'pago' ? 'success' : 'danger'; ?>">
                            <?php echo $ordem['status_pagamento'] === 'pago' ? 'PAGO' : 'PENDENTE'; ?>
                        </span>
                    </p>
                    <p><strong>Forma de Pagamento:</strong> <?php echo htmlspecialchars($ordem['pagamento_nome']); ?></p>
                </div>
            </div>
            
            <!-- Informações do Cliente -->
            <div class="detalhes-cliente">
                <h5>Dados do Cliente</h5>
                <div class="row">
                    <div class="col-md-6">
                        <p><strong>Nome:</strong> 
                            <?php 
                            if ($ordem['cliente_tipo'] === 'anonimo') {
                                echo 'CLIENTE ANÔNIMO';
                            } else {
                                echo htmlspecialchars($ordem['cliente_nome'] ?? 'N/A');
                            }
                            ?>
                        </p>
                        <?php if ($ordem['cliente_tipo'] !== 'anonimo' && !empty($ordem['cliente_cpf_cnpj'])): ?>
                            <p><strong>CPF/CNPJ:</strong> <?php echo htmlspecialchars($ordem['cliente_cpf_cnpj']); ?></p>
                        <?php endif; ?>
                    </div>
                    <div class="col-md-6">
                        <?php if ($ordem['cliente_tipo'] !== 'anonimo'): ?>
                            <?php if (!empty($ordem['cliente_telefone'])): ?>
                                <p><strong>Telefone:</strong> <?php echo htmlspecialchars($ordem['cliente_telefone']); ?></p>
                            <?php endif; ?>
                            <?php if (!empty($ordem['cliente_endereco'])): ?>
                                <p><strong>Endereço:</strong> <?php echo htmlspecialchars($ordem['cliente_endereco']); ?></p>
                            <?php endif; ?>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            
            <!-- Itens da Ordem -->
            <table class="table-nota">
                <thead>
                    <tr>
                        <th>Item</th>
                        <th>Descrição do Serviço</th>
                        <th>Quantidade</th>
                        <th>Valor Unitário</th>
                        <th>Subtotal</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($item = $itens->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo $item['id']; ?></td>
                            <td><?php echo htmlspecialchars($item['servico_nome']); ?></td>
                            <td><?php echo $item['quantidade']; ?></td>
                            <td><?php echo formatarMoeda($item['valor_unitario']); ?></td>
                            <td><?php echo formatarMoeda($item['subtotal']); ?></td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
            
            <!-- Totais -->
            <div class="total-box">
                <p><strong>VALOR TOTAL:</strong> <?php echo formatarMoeda($ordem['valor_total']); ?></p>
                <p><strong>DESCONTO:</strong> <?php echo formatarMoeda($ordem['desconto']); ?></p>
                <h4><strong>VALOR FINAL:</strong> <?php echo formatarMoeda($ordem['valor_final']); ?></h4>
            </div>
            
            <!-- Observações -->
            <?php if (!empty($ordem['observacoes'])): ?>
                <div class="observacoes">
                    <h5>Observações:</h5>
                    <p><?php echo nl2br(htmlspecialchars($ordem['observacoes'])); ?></p>
                </div>
            <?php endif; ?>
            
            <!-- Assinaturas -->
            <div class="row assinatura">
                <div class="col-md-6">
                    <p>_________________________________</p>
                    <p>Responsável pela Copiadora</p>
                </div>
                <div class="col-md-6">
                    <p>_________________________________</p>
                    <p>Cliente</p>
                </div>
            </div>
            
            <!-- Rodapé -->
            <div class="text-center mt-4">
                <p><em>Agradecemos pela preferência! Volte sempre!</em></p>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        function marcarComoPago() {
            if (confirm('Tem certeza que deseja marcar esta ordem como PAGA?')) {
                fetch('ajax/marcar_pago.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                    },
                    body: 'ordem_id=<?php echo $ordem_id; ?>'
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        alert('Ordem marcada como paga!');
                        location.reload();
                    } else {
                        alert('Erro ao atualizar status!');
                    }
                })
                .catch(error => {
                    alert('Erro ao processar solicitação!');
                });
            }
        }
    </script>
</body>
</html>