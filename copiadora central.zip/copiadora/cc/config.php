<?php
// config.php - VERSÃO CORRIGIDA
// Configurações do banco de dados
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'copiadora_central');

// Informações da empresa
define('EMPRESA_NOME', 'Copiadora Central');
define('EMPRESA_CNPJ', '35.885.228/0001-90');
define('EMPRESA_ENDERECO', 'Rua Argemiro de Aguilar, 498 - Centro');
define('EMPRESA_CIDADE', 'Almenara - MG');
define('EMPRESA_TELEFONE', '(33) 99972-1488');
define('EMPRESA_EMAIL', 'copiadoracentral.almenara@hotmail.com');

// Iniciar sessão apenas se não estiver ativa
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Conexão com o banco de dados
function conectarBanco() {
    $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
    
    if ($conn->connect_error) {
        die("Erro na conexão: " . $conn->connect_error);
    }
    
    $conn->set_charset("utf8");
    return $conn;
}

// Verificar se usuário está logado
function verificarLogin() {
    if (!isset($_SESSION['usuario_id'])) {
        header('Location: login.php');
        exit();
    }
}

// Formatar moeda
function formatarMoeda($valor) {
    return 'R$ ' . number_format($valor, 2, ',', '.');
}

// Formatar data
function formatarData($data, $formato = 'd/m/Y') {
    if (empty($data) || $data == '0000-00-00') return '';
    try {
        $date = new DateTime($data);
        return $date->format($formato);
    } catch (Exception $e) {
        return '';
    }
}

// Gerar hash de senha
function gerarHashSenha($senha) {
    return password_hash($senha, PASSWORD_DEFAULT);
}

// Verificar senha
function verificarSenha($senha, $hash) {
    return password_verify($senha, $hash);
}

// Registrar log - VERSÃO SEGURA (não falha se tabela não existir)
function registrarLog($usuario_id, $acao, $descricao) {
    try {
        $conn = conectarBanco();
        $ip = $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1';
        
        // Verificar se a tabela logs_sistema existe
        $result = $conn->query("SHOW TABLES LIKE 'logs_sistema'");
        
        if ($result->num_rows > 0) {
            // Tabela existe, inserir log
            $stmt = $conn->prepare("INSERT INTO logs_sistema (usuario_id, acao, descricao, ip) VALUES (?, ?, ?, ?)");
            if ($stmt) {
                $stmt->bind_param("isss", $usuario_id, $acao, $descricao, $ip);
                $stmt->execute();
                $stmt->close();
            }
        } else {
            // Tabela não existe, apenas registrar no log do PHP
            error_log("LOG SISTEMA - Usuário ID: {$usuario_id}, Ação: {$acao}, Descrição: {$descricao}, IP: {$ip}");
        }
        
        $conn->close();
    } catch (Exception $e) {
        // Ignorar erro de log, não interromper o fluxo
        error_log("Erro ao registrar log: " . $e->getMessage());
    }
}

// Sanitizar entrada
function sanitizar($dados) {
    if (is_array($dados)) {
        return array_map('sanitizar', $dados);
    }
    return htmlspecialchars(trim($dados), ENT_QUOTES, 'UTF-8');
}

// Redirecionar com mensagem
function redirecionarComMensagem($url, $tipo, $mensagem) {
    $_SESSION['mensagem'] = $mensagem;
    $_SESSION['mensagem_tipo'] = $tipo;
    header("Location: $url");
    exit();
}

// Obter mensagem flash
function obterMensagemFlash() {
    if (isset($_SESSION['mensagem'])) {
        $mensagem = $_SESSION['mensagem'];
        $tipo = $_SESSION['mensagem_tipo'] ?? 'info';
        unset($_SESSION['mensagem']);
        unset($_SESSION['mensagem_tipo']);
        return ['texto' => $mensagem, 'tipo' => $tipo];
    }
    return null;
}
?>