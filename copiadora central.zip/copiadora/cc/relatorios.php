<?php
// relatorios.php
require_once 'config.php';
verificarLogin();

$conn = conectarBanco();

// Período para relatório
$data_inicio = $_GET['data_inicio'] ?? date('Y-m-01');
$data_fim = $_GET['data_fim'] ?? date('Y-m-d');

// Relatório de serviços mais vendidos
$servicos_vendidos = $conn->query("
    SELECT s.nome, SUM(oi.quantidade) as total_vendido, SUM(oi.subtotal) as total_valor
    FROM ordem_itens oi
    JOIN servicos s ON oi.servico_id = s.id
    JOIN ordens_servico os ON oi.ordem_id = os.id
    WHERE os.data_ordem BETWEEN '$data_inicio' AND '$data_fim 23:59:59'
    GROUP BY s.id
    ORDER BY total_vendido DESC
    LIMIT 10
");

// Relatório por forma de pagamento
$pagamentos = $conn->query("
    SELECT tp.nome, COUNT(os.id) as total_ordens, SUM(os.valor_final) as total_valor
    FROM ordens_servico os
    JOIN tipos_pagamento tp ON os.tipo_pagamento_id = tp.id
    WHERE os.data_ordem BETWEEN '$data_inicio' AND '$data_fim 23:59:59'
    AND os.status_pagamento = 'pago'
    GROUP BY tp.id
    ORDER BY total_valor DESC
");

// Relatório de clientes que mais compraram
$clientes = $conn->query("
    SELECT c.nome, COUNT(os.id) as total_ordens, SUM(os.valor_final) as total_gasto
    FROM ordens_servico os
    JOIN clientes c ON os.cliente_id = c.id
    WHERE os.data_ordem BETWEEN '$data_inicio' AND '$data_fim 23:59:59'
    GROUP BY c.id
    ORDER BY total_gasto DESC
    LIMIT 10
");

// Totais gerais
$total_recebido = $conn->query("
    SELECT SUM(valor_final) as total FROM ordens_servico 
    WHERE data_ordem BETWEEN '$data_inicio' AND '$data_fim 23:59:59'
    AND status_pagamento = 'pago'
")->fetch_assoc()['total'];

$total_pendente = $conn->query("
    SELECT SUM(valor_final) as total FROM ordens_servico 
    WHERE data_ordem BETWEEN '$data_inicio' AND '$data_fim 23:59:59'
    AND status_pagamento = 'pendente'
")->fetch_assoc()['total'];

$total_ordens = $conn->query("
    SELECT COUNT(*) as total FROM ordens_servico 
    WHERE data_ordem BETWEEN '$data_inicio' AND '$data_fim 23:59:59'
")->fetch_assoc()['total'];

$total_gastos = $conn->query("
    SELECT SUM(valor) as total FROM gastos 
    WHERE data_gasto BETWEEN '$data_inicio' AND '$data_fim'
")->fetch_assoc()['total'];

$total_recebido = $total_recebido ?: 0;
$total_pendente = $total_pendente ?: 0;
$total_ordens = $total_ordens ?: 0;
$total_gastos = $total_gastos ?: 0;
$lucro = $total_recebido - $total_gastos;
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Relatórios - Copiadora Central</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        .card-relatorio {
            height: 100%;
        }
        .chart-container {
            position: relative;
            height: 300px;
            width: 100%;
        }
        .stat-card {
            border-radius: 10px;
            color: white;
            padding: 15px;
            margin-bottom: 15px;
        }
        .stat-card h3 {
            margin: 0;
            font-weight: bold;
        }
    </style>
</head>
<body>
    <?php include 'navbar.php'; ?>
    
    <div class="container-fluid mt-4">
        <div class="row">
            <?php include 'sidebar.php'; ?>
            
            <div class="col-md-10">
                <h2>Relatórios</h2>
                
                <!-- Filtros -->
                <div class="card mb-3">
                    <div class="card-header">
                        <h5>Filtros do Relatório</h5>
                    </div>
                    <div class="card-body">
                        <form method="GET" class="row">
                            <div class="col-md-4">
                                <label for="data_inicio" class="form-label">Data Início</label>
                                <input type="date" class="form-control" id="data_inicio" name="data_inicio" 
                                       value="<?php echo $data_inicio; ?>">
                            </div>
                            <div class="col-md-4">
                                <label for="data_fim" class="form-label">Data Fim</label>
                                <input type="date" class="form-control" id="data_fim" name="data_fim" 
                                       value="<?php echo $data_fim; ?>">
                            </div>
                            <div class="col-md-4 d-flex align-items-end">
                                <button type="submit" class="btn btn-primary me-2">
                                    <i class="bi bi-filter"></i> Filtrar
                                </button>
                                <button type="button" onclick="window.print()" class="btn btn-secondary">
                                    <i class="bi bi-printer"></i> Imprimir
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
                
                <!-- Cards de Estatísticas -->
                <div class="row mb-4">
                    <div class="col-md-3">
                        <div class="stat-card bg-primary">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <h6>Total Recebido</h6>
                                    <h3><?php echo formatarMoeda($total_recebido); ?></h3>
                                </div>
                                <i class="bi bi-cash fs-1"></i>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="stat-card bg-warning">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <h6>Total Pendente</h6>
                                    <h3><?php echo formatarMoeda($total_pendente); ?></h3>
                                </div>
                                <i class="bi bi-clock fs-1"></i>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="stat-card bg-danger">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <h6>Total Gastos</h6>
                                    <h3><?php echo formatarMoeda($total_gastos); ?></h3>
                                </div>
                                <i class="bi bi-cash-stack fs-1"></i>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="stat-card bg-success">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <h6>Lucro Líquido</h6>
                                    <h3><?php echo formatarMoeda($lucro); ?></h3>
                                </div>
                                <i class="bi bi-graph-up fs-1"></i>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="row">
                    <!-- Serviços mais vendidos -->
                    <div class="col-md-6">
                        <div class="card card-relatorio">
                            <div class="card-header">
                                <h5>Serviços Mais Vendidos</h5>
                            </div>
                            <div class="card-body">
                                <div class="chart-container">
                                    <canvas id="chartServicos"></canvas>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Formas de pagamento -->
                    <div class="col-md-6">
                        <div class="card card-relatorio">
                            <div class="card-header">
                                <h5>Recebimento por Forma de Pagamento</h5>
                            </div>
                            <div class="card-body">
                                <div class="chart-container">
                                    <canvas id="chartPagamentos"></canvas>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Tabelas detalhadas -->
                <div class="row mt-4">
                    <div class="col-md-6">
                        <div class="card">
                            <div class="card-header">
                                <h5>Top 10 Clientes</h5>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table table-sm">
                                        <thead>
                                            <tr>
                                                <th>Cliente</th>
                                                <th>Total de Ordens</th>
                                                <th>Total Gasto</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php while ($cliente = $clientes->fetch_assoc()): ?>
                                                <tr>
                                                    <td><?php echo htmlspecialchars($cliente['nome']); ?></td>
                                                    <td><?php echo $cliente['total_ordens']; ?></td>
                                                    <td><?php echo formatarMoeda($cliente['total_gasto']); ?></td>
                                                </tr>
                                            <?php endwhile; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-md-6">
                        <div class="card">
                            <div class="card-header">
                                <h5>Detalhes por Pagamento</h5>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table table-sm">
                                        <thead>
                                            <tr>
                                                <th>Forma de Pagamento</th>
                                                <th>Ordens</th>
                                                <th>Valor Total</th>
                                                <th>%</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php while ($pagamento = $pagamentos->fetch_assoc()): ?>
                                                <?php 
                                                    $percentual = $total_recebido > 0 ? ($pagamento['total_valor'] / $total_recebido) * 100 : 0;
                                                ?>
                                                <tr>
                                                    <td><?php echo htmlspecialchars($pagamento['nome']); ?></td>
                                                    <td><?php echo $pagamento['total_ordens']; ?></td>
                                                    <td><?php echo formatarMoeda($pagamento['total_valor']); ?></td>
                                                    <td><?php echo number_format($percentual, 1); ?>%</td>
                                                </tr>
                                            <?php endwhile; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Gráfico de serviços mais vendidos
        const ctxServicos = document.getElementById('chartServicos').getContext('2d');
        const chartServicos = new Chart(ctxServicos, {
            type: 'bar',
            data: {
                labels: [
                    <?php 
                    $servicos_vendidos->data_seek(0);
                    while ($servico = $servicos_vendidos->fetch_assoc()): 
                        echo "'" . addslashes(substr($servico['nome'], 0, 20)) . "',";
                    endwhile;
                    ?>
                ],
                datasets: [{
                    label: 'Quantidade Vendida',
                    data: [
                        <?php 
                        $servicos_vendidos->data_seek(0);
                        while ($servico = $servicos_vendidos->fetch_assoc()): 
                            echo $servico['total_vendido'] . ",";
                        endwhile;
                        ?>
                    ],
                    backgroundColor: 'rgba(54, 162, 235, 0.5)',
                    borderColor: 'rgba(54, 162, 235, 1)',
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
        
        // Gráfico de formas de pagamento
        const ctxPagamentos = document.getElementById('chartPagamentos').getContext('2d');
        const chartPagamentos = new Chart(ctxPagamentos, {
            type: 'pie',
            data: {
                labels: [
                    <?php 
                    $pagamentos->data_seek(0);
                    while ($pagamento = $pagamentos->fetch_assoc()): 
                        echo "'" . addslashes($pagamento['nome']) . "',";
                    endwhile;
                    ?>
                ],
                datasets: [{
                    data: [
                        <?php 
                        $pagamentos->data_seek(0);
                        while ($pagamento = $pagamentos->fetch_assoc()): 
                            echo $pagamento['total_valor'] . ",";
                        endwhile;
                        ?>
                    ],
                    backgroundColor: [
                        '#FF6384',
                        '#36A2EB',
                        '#FFCE56',
                        '#4BC0C0',
                        '#9966FF',
                        '#FF9F40'
                    ]
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false
            }
        });
    </script>
</body>
</html>