<?php
// orcamentos.php
require_once 'config.php';
verificarLogin();

$conn = conectarBanco();
$acao = $_GET['acao'] ?? 'listar';

// Processar ações
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['salvar_orcamento'])) {
        // Salvar orçamento principal
        $cliente_id = $_POST['cliente_id'] == 'anonimo' ? NULL : $_POST['cliente_id'];
        $valido_ate = $_POST['valido_ate'];
        $observacoes = $_POST['observacoes'];
        
        // Calcular valores
        $total = 0;
        if (isset($_POST['servico_id'])) {
            foreach ($_POST['servico_id'] as $key => $servico_id) {
                $quantidade = $_POST['quantidade'][$key];
                $valor_unitario = str_replace(',', '.', str_replace('.', '', $_POST['valor_unitario'][$key]));
                $subtotal = $quantidade * $valor_unitario;
                $total += $subtotal;
            }
        }
        
        // Inserir orçamento
        $stmt = $conn->prepare("INSERT INTO orcamentos (cliente_id, valido_ate, observacoes, valor_total) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("sssd", $cliente_id, $valido_ate, $observacoes, $total);
        
        if ($stmt->execute()) {
            $orcamento_id = $conn->insert_id;
            
            // Inserir itens
            if (isset($_POST['servico_id'])) {
                foreach ($_POST['servico_id'] as $key => $servico_id) {
                    $quantidade = $_POST['quantidade'][$key];
                    $valor_unitario = str_replace(',', '.', str_replace('.', '', $_POST['valor_unitario'][$key]));
                    $subtotal = $quantidade * $valor_unitario;
                    
                    $stmt_item = $conn->prepare("INSERT INTO orcamento_itens (orcamento_id, servico_id, quantidade, valor_unitario, subtotal) VALUES (?, ?, ?, ?, ?)");
                    $stmt_item->bind_param("iiidd", $orcamento_id, $servico_id, $quantidade, $valor_unitario, $subtotal);
                    $stmt_item->execute();
                }
            }
            
            header('Location: ver_orcamento.php?id=' . $orcamento_id);
            exit();
        }
    } elseif (isset($_POST['atualizar_status'])) {
        $id = $_POST['id'];
        $status = $_POST['status'];
        
        $stmt = $conn->prepare("UPDATE orcamentos SET status=? WHERE id=?");
        $stmt->bind_param("si", $status, $id);
        $stmt->execute();
        
        header('Location: orcamentos.php?msg=status');
        exit();
    } elseif (isset($_POST['converter_para_ordem'])) {
        $orcamento_id = $_POST['orcamento_id'];
        
        // Buscar dados do orçamento
        $orcamento = $conn->query("SELECT * FROM orcamentos WHERE id = $orcamento_id")->fetch_assoc();
        
        // Criar nova ordem de serviço
        $stmt = $conn->prepare("INSERT INTO ordens_servico (cliente_id, orcamento_id, data_entrega, valor_total, valor_final, observacoes) VALUES (?, ?, ?, ?, ?, ?)");
        
        // Definir data de entrega padrão (validade + 2 dias)
        $data_entrega = date('Y-m-d', strtotime($orcamento['valido_ate'] . ' +2 days'));
        
        $stmt->bind_param("iisddd", 
            $orcamento['cliente_id'], 
            $orcamento_id, 
            $data_entrega, 
            $orcamento['valor_total'], 
            $orcamento['valor_total'], 
            $orcamento['observacoes']
        );
        
        if ($stmt->execute()) {
            $ordem_id = $conn->insert_id;
            
            // Buscar itens do orçamento
            $itens = $conn->query("SELECT * FROM orcamento_itens WHERE orcamento_id = $orcamento_id");
            
            // Copiar itens para a ordem
            while ($item = $itens->fetch_assoc()) {
                $stmt_item = $conn->prepare("INSERT INTO ordem_itens (ordem_id, servico_id, quantidade, valor_unitario, subtotal) VALUES (?, ?, ?, ?, ?)");
                $stmt_item->bind_param("iiidd", $ordem_id, $item['servico_id'], $item['quantidade'], $item['valor_unitario'], $item['subtotal']);
                $stmt_item->execute();
            }
            
            // Atualizar status do orçamento
            $conn->query("UPDATE orcamentos SET status='convertido' WHERE id = $orcamento_id");
            
            header('Location: notas.php?ordem=' . $ordem_id);
            exit();
        }
    }
}

// Listar orçamentos
$orcamentos = [];
if ($acao === 'listar') {
    $query = "
        SELECT o.*, 
               c.nome as cliente_nome,
               c.tipo as cliente_tipo
        FROM orcamentos o
        LEFT JOIN clientes c ON o.cliente_id = c.id
        ORDER BY o.data_orcamento DESC
    ";
    $result = $conn->query($query);
    while ($row = $result->fetch_assoc()) {
        $orcamentos[] = $row;
    }
}

// Buscar clientes para select
$clientes = $conn->query("SELECT id, nome, tipo FROM clientes ORDER BY nome");
$servicos = $conn->query("SELECT * FROM servicos WHERE ativo = 1 ORDER BY nome");
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Orçamentos - Copiadora Central</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css">
    <style>
        .item-servico {
            background: #f8f9fa;
            border-radius: 5px;
            padding: 15px;
            margin-bottom: 10px;
        }
        .total-box {
            background: #f0f7ff;
            border-radius: 5px;
            padding: 20px;
            font-size: 1.2em;
            font-weight: bold;
        }
        .servico-header {
            background: #e9ecef;
            padding: 10px;
            border-radius: 5px;
            margin-bottom: 10px;
            font-weight: bold;
        }
        .status-badge {
            font-size: 0.8em;
            padding: 5px 10px;
        }
    </style>
</head>
<body>
    <?php include 'navbar.php'; ?>
    
    <div class="container-fluid mt-4">
        <div class="row">
            <?php include 'sidebar.php'; ?>
            
            <div class="col-md-10">
                <h2>Orçamentos</h2>
                
                <?php if ($acao === 'listar'): ?>
                    <div class="mb-3">
                        <a href="orcamentos.php?acao=novo" class="btn btn-primary">
                            <i class="bi bi-plus-circle me-2"></i> Novo Orçamento
                        </a>
                    </div>
                    
                    <?php if (isset($_GET['msg'])): ?>
                        <div class="alert alert-success">
                            Status atualizado com sucesso!
                        </div>
                    <?php endif; ?>
                    
                    <div class="card">
                        <div class="card-header">
                            <h5>Todos os Orçamentos</h5>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-striped table-hover">
                                    <thead>
                                        <tr>
                                            <th>ID</th>
                                            <th>Cliente</th>
                                            <th>Data</th>
                                            <th>Válido Até</th>
                                            <th>Valor Total</th>
                                            <th>Status</th>
                                            <th>Ações</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($orcamentos as $orcamento): ?>
                                            <tr>
                                                <td>#<?php echo $orcamento['id']; ?></td>
                                                <td>
                                                    <?php if ($orcamento['cliente_tipo'] === 'anonimo'): ?>
                                                        <span class="badge bg-warning">Anônimo</span>
                                                    <?php else: ?>
                                                        <?php echo htmlspecialchars($orcamento['cliente_nome'] ?? 'N/A'); ?>
                                                    <?php endif; ?>
                                                </td>
                                                <td><?php echo formatarData($orcamento['data_orcamento'], 'd/m/Y'); ?></td>
                                                <td><?php echo formatarData($orcamento['valido_ate']); ?></td>
                                                <td><?php echo formatarMoeda($orcamento['valor_total']); ?></td>
                                                <td>
                                                    <span class="badge status-badge bg-<?php 
                                                        switch($orcamento['status']) {
                                                            case 'pendente': echo 'warning'; break;
                                                            case 'aprovado': echo 'success'; break;
                                                            case 'rejeitado': echo 'danger'; break;
                                                            case 'convertido': echo 'info'; break;
                                                        }
                                                    ?>">
                                                        <?php echo ucfirst($orcamento['status']); ?>
                                                    </span>
                                                </td>
                                                <td>
                                                    <a href="ver_orcamento.php?id=<?php echo $orcamento['id']; ?>" class="btn btn-sm btn-info" target="_blank">
                                                        <i class="bi bi-eye"></i>
                                                    </a>
                                                    <button class="btn btn-sm btn-warning" data-bs-toggle="modal" data-bs-target="#modalStatus<?php echo $orcamento['id']; ?>">
                                                        <i class="bi bi-pencil"></i>
                                                    </button>
                                                    <?php if ($orcamento['status'] == 'aprovado'): ?>
                                                        <form method="POST" style="display: inline;">
                                                            <input type="hidden" name="orcamento_id" value="<?php echo $orcamento['id']; ?>">
                                                            <button type="submit" name="converter_para_ordem" class="btn btn-sm btn-success">
                                                                <i class="bi bi-arrow-right-circle"></i>
                                                            </button>
                                                        </form>
                                                    <?php endif; ?>
                                                </td>
                                            </tr>
                                            
                                            <!-- Modal de Status -->
                                            <div class="modal fade" id="modalStatus<?php echo $orcamento['id']; ?>" tabindex="-1">
                                                <div class="modal-dialog">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <h5 class="modal-title">Alterar Status - Orçamento #<?php echo $orcamento['id']; ?></h5>
                                                            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                                        </div>
                                                        <form method="POST">
                                                            <div class="modal-body">
                                                                <input type="hidden" name="id" value="<?php echo $orcamento['id']; ?>">
                                                                
                                                                <div class="mb-3">
                                                                    <label for="status<?php echo $orcamento['id']; ?>" class="form-label">Status</label>
                                                                    <select class="form-select" id="status<?php echo $orcamento['id']; ?>" name="status">
                                                                        <option value="pendente" <?php echo $orcamento['status'] === 'pendente' ? 'selected' : ''; ?>>Pendente</option>
                                                                        <option value="aprovado" <?php echo $orcamento['status'] === 'aprovado' ? 'selected' : ''; ?>>Aprovado</option>
                                                                        <option value="rejeitado" <?php echo $orcamento['status'] === 'rejeitado' ? 'selected' : ''; ?>>Rejeitado</option>
                                                                        <option value="convertido" <?php echo $orcamento['status'] === 'convertido' ? 'selected' : ''; ?>>Convertido</option>
                                                                    </select>
                                                                </div>
                                                            </div>
                                                            <div class="modal-footer">
                                                                <button type="submit" name="atualizar_status" class="btn btn-primary">Salvar</button>
                                                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                                                            </div>
                                                        </form>
                                                    </div>
                                                </div>
                                            </div>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
                
                <?php if ($acao === 'novo'): ?>
                    <div class="card">
                        <div class="card-header">
                            <h5>Novo Orçamento</h5>
                        </div>
                        <div class="card-body">
                            <form method="POST" id="formOrcamento">
                                <div class="row mb-3">
                                    <div class="col-md-6">
                                        <label for="cliente_id" class="form-label">Cliente</label>
                                        <select class="form-select" id="cliente_id" name="cliente_id" required>
                                            <option value="">Selecione um cliente...</option>
                                            <option value="anonimo">Cliente Anônimo</option>
                                            <?php 
                                            if ($clientes->num_rows > 0):
                                                while ($cliente = $clientes->fetch_assoc()): ?>
                                                    <option value="<?php echo $cliente['id']; ?>">
                                                        <?php echo htmlspecialchars($cliente['nome']); ?>
                                                        <?php if ($cliente['tipo'] === 'anonimo'): ?> (Anônimo)<?php endif; ?>
                                                    </option>
                                                <?php endwhile; 
                                            else: ?>
                                                <option value="">Nenhum cliente cadastrado</option>
                                            <?php endif; ?>
                                        </select>
                                    </div>
                                    <div class="col-md-6">
                                        <label for="valido_ate" class="form-label">Válido Até</label>
                                        <input type="date" class="form-control" id="valido_ate" name="valido_ate" required
                                               value="<?php echo date('Y-m-d', strtotime('+15 days')); ?>">
                                    </div>
                                </div>
                                
                                <div class="servico-header">
                                    <h5 class="mb-0">Serviços do Orçamento</h5>
                                    <small>Adicione os serviços para este orçamento</small>
                                </div>
                                
                                <div id="servicos-container">
                                    <!-- Serviços serão adicionados aqui via JavaScript -->
                                </div>
                                
                                <div class="mb-3">
                                    <button type="button" class="btn btn-success" onclick="adicionarServico()">
                                        <i class="bi bi-plus-circle me-2"></i> Adicionar Serviço
                                    </button>
                                </div>
                                
                                <div class="row mb-3">
                                    <div class="col-md-8">
                                        <label for="observacoes" class="form-label">Observações</label>
                                        <textarea class="form-control" id="observacoes" name="observacoes" rows="3" placeholder="Observações sobre o orçamento..."></textarea>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="total-box text-center">
                                            <div class="text-primary">Valor Total: <span id="valor-total">R$ 0,00</span></div>
                                            <small class="text-muted">Válido até: <span id="data-validade"><?php echo date('d/m/Y', strtotime('+15 days')); ?></span></small>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="d-flex gap-2">
                                    <button type="submit" name="salvar_orcamento" class="btn btn-primary">
                                        <i class="bi bi-save me-2"></i> Salvar Orçamento
                                    </button>
                                    <a href="orcamentos.php" class="btn btn-secondary">Cancelar</a>
                                </div>
                            </form>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Dados dos serviços
        const servicos = [
            <?php 
            if ($servicos->num_rows > 0) {
                $servicos->data_seek(0);
                while ($servico = $servicos->fetch_assoc()): 
            ?>
            {
                id: <?php echo $servico['id']; ?>,
                nome: "<?php echo addslashes($servico['nome']); ?>",
                valor: <?php echo $servico['valor']; ?>
            },
            <?php 
                endwhile;
            } else {
                echo '{id: 0, nome: "Nenhum serviço cadastrado", valor: 0}';
            }
            ?>
        ];
        
        let contadorServicos = 0;
        
        function adicionarServico(servicoId = '', quantidade = 1, valorUnitario = 0) {
            const container = document.getElementById('servicos-container');
            const index = contadorServicos++;
            
            const servicoHtml = `
                <div class="item-servico" id="servico-${index}">
                    <div class="row">
                        <div class="col-md-4">
                            <label class="form-label">Serviço</label>
                            <select class="form-select servico-select" name="servico_id[]" onchange="atualizarValor(${index})" required>
                                <option value="">Selecione um serviço...</option>
                                ${servicos.map(s => `
                                    <option value="${s.id}" ${servicoId == s.id ? 'selected' : ''}>
                                        ${s.nome} - R$ ${s.valor.toFixed(2).replace('.', ',')}
                                    </option>
                                `).join('')}
                            </select>
                        </div>
                        <div class="col-md-2">
                            <label class="form-label">Quantidade</label>
                            <input type="number" class="form-control quantidade" name="quantidade[]" 
                                   value="${quantidade}" min="1" onchange="calcularSubtotal(${index})" oninput="calcularSubtotal(${index})" required>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label">Valor Unitário (R$)</label>
                            <input type="text" class="form-control valor-unitario" name="valor_unitario[]" 
                                   value="${valorUnitario ? valorUnitario.toFixed(2).replace('.', ',') : '0,00'}" 
                                   onchange="calcularSubtotal(${index})" oninput="calcularSubtotal(${index})" required>
                        </div>
                        <div class="col-md-2">
                            <label class="form-label">Subtotal</label>
                            <input type="text" class="form-control subtotal" readonly 
                                   value="R$ 0,00">
                        </div>
                        <div class="col-md-1 d-flex align-items-end">
                            <button type="button" class="btn btn-danger btn-sm" onclick="removerServico(${index})">
                                <i class="bi bi-trash"></i>
                            </button>
                        </div>
                    </div>
                </div>
            `;
            
            container.insertAdjacentHTML('beforeend', servicoHtml);
            
            // Adicionar máscara ao campo de valor unitário
            const valorInput = document.querySelector(`#servico-${index} .valor-unitario`);
            if (valorInput) {
                valorInput.addEventListener('input', function(e) {
                    let value = e.target.value.replace(/\D/g, '');
                    value = (value / 100).toFixed(2) + '';
                    value = value.replace('.', ',');
                    value = value.replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1.');
                    e.target.value = value;
                    calcularSubtotal(index);
                });
            }
            
            if (servicoId) {
                atualizarValor(index);
            } else {
                calcularSubtotal(index);
            }
        }
        
        function removerServico(index) {
            const elemento = document.getElementById(`servico-${index}`);
            if (elemento) {
                elemento.remove();
                calcularTotal();
            }
        }
        
        function atualizarValor(index) {
            const select = document.querySelector(`#servico-${index} .servico-select`);
            if (!select) return;
            
            const servicoId = select.value;
            const servico = servicos.find(s => s.id == servicoId);
            
            if (servico) {
                const valorInput = document.querySelector(`#servico-${index} .valor-unitario`);
                if (valorInput) {
                    valorInput.value = servico.valor.toFixed(2).replace('.', ',');
                    calcularSubtotal(index);
                }
            }
        }
        
        function calcularSubtotal(index) {
            const quantidadeInput = document.querySelector(`#servico-${index} .quantidade`);
            const valorInput = document.querySelector(`#servico-${index} .valor-unitario`);
            const subtotalInput = document.querySelector(`#servico-${index} .subtotal`);
            
            if (!quantidadeInput || !valorInput || !subtotalInput) return;
            
            const quantidade = parseFloat(quantidadeInput.value) || 0;
            const valorUnitario = parseFloat(
                valorInput.value.replace(/\./g, '').replace(',', '.')
            ) || 0;
            
            const subtotal = quantidade * valorUnitario;
            subtotalInput.value = 'R$ ' + subtotal.toFixed(2).replace('.', ',');
            
            calcularTotal();
        }
        
        function calcularTotal() {
            let total = 0;
            
            document.querySelectorAll('.subtotal').forEach(input => {
                const valor = parseFloat(input.value.replace('R$ ', '').replace('.', '').replace(',', '.')) || 0;
                total += valor;
            });
            
            document.getElementById('valor-total').textContent = 'R$ ' + total.toFixed(2).replace('.', ',');
        }
        
        // Atualizar data de validade exibida
        function atualizarDataValidade() {
            const input = document.getElementById('valido_ate');
            const dataSpan = document.getElementById('data-validade');
            if (input && dataSpan) {
                const data = new Date(input.value);
                const options = { day: '2-digit', month: '2-digit', year: 'numeric' };
                dataSpan.textContent = data.toLocaleDateString('pt-BR');
            }
        }
        
        // Adicionar um serviço ao carregar a página
        document.addEventListener('DOMContentLoaded', function() {
            adicionarServico();
            
            // Atualizar data de validade quando mudar
            const validoAteInput = document.getElementById('valido_ate');
            if (validoAteInput) {
                validoAteInput.addEventListener('change', atualizarDataValidade);
                atualizarDataValidade();
            }
            
            // Validar formulário antes de enviar
            document.getElementById('formOrcamento')?.addEventListener('submit', function(e) {
                // Verificar se há pelo menos um serviço
                const servicosCount = document.querySelectorAll('.item-servico').length;
                if (servicosCount === 0) {
                    e.preventDefault();
                    alert('Adicione pelo menos um serviço ao orçamento!');
                    return false;
                }
                
                // Verificar se todos os serviços estão preenchidos
                let todosPreenchidos = true;
                document.querySelectorAll('.servico-select').forEach(select => {
                    if (!select.value) {
                        todosPreenchidos = false;
                        select.classList.add('is-invalid');
                    } else {
                        select.classList.remove('is-invalid');
                    }
                });
                
                if (!todosPreenchidos) {
                    e.preventDefault();
                    alert('Preencha todos os serviços do orçamento!');
                    return false;
                }
                
                return true;
            });
            
            // Calcular total inicial
            calcularTotal();
        });
    </script>
</body>
</html>