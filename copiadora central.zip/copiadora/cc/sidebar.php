<!-- sidebar.php CORRIGIDO -->
<div class="col-md-2 p-0 bg-dark text-white">
    <div class="p-3">
        <h5 class="text-center">Copiadora Central</h5>
        <hr>
    </div>
    
    <nav class="nav flex-column p-2">
        <!-- Dashboard -->
        <a class="nav-link text-white <?php echo basename($_SERVER['PHP_SELF']) == 'index.php' ? 'bg-primary' : ''; ?>" href="index.php">
            <i class="bi bi-speedometer2 me-2"></i> Dashboard
        </a>
        
        <!-- Clientes -->
        <a class="nav-link text-white <?php echo basename($_SERVER['PHP_SELF']) == 'clientes.php' ? 'bg-primary' : ''; ?>" href="clientes.php">
            <i class="bi bi-people me-2"></i> Clientes
        </a>
        
        <!-- Pendências (com contador) -->
        <?php
        // Contar pendências
        $conn = conectarBanco();
        $result = $conn->query("
            SELECT COUNT(DISTINCT c.id) as total 
            FROM clientes c 
            INNER JOIN ordens_servico os ON c.id = os.cliente_id 
            WHERE os.status_pagamento = 'pendente'
            AND os.status NOT IN ('cancelado')
        ");
        $row = $result->fetch_assoc();
        $total_pendentes = $row['total'] ?? 0;
        $conn->close();
        ?>
        
        <a class="nav-link text-white <?php echo basename($_SERVER['PHP_SELF']) == 'clientes_pendentes.php' ? 'bg-primary' : ''; ?>" 
           href="clientes_pendentes.php">
            <i class="bi bi-clock-history me-2"></i>
            Pendências
            <?php if ($total_pendentes > 0): ?>
                <span class="badge bg-danger rounded-pill float-end mt-1">
                    <?php echo $total_pendentes; ?>
                </span>
            <?php endif; ?>
        </a>
        
        <!-- Serviços -->
        <a class="nav-link text-white <?php echo basename($_SERVER['PHP_SELF']) == 'servicos.php' ? 'bg-primary' : ''; ?>" href="servicos.php">
            <i class="bi bi-list-task me-2"></i> Serviços
        </a>
        
        <!-- Orçamentos -->
        <a class="nav-link text-white <?php echo basename($_SERVER['PHP_SELF']) == 'orcamentos.php' ? 'bg-primary' : ''; ?>" href="orcamentos.php">
            <i class="bi bi-calculator me-2"></i> Orçamentos
        </a>
        
        <!-- Ordens de Serviço -->
        <a class="nav-link text-white <?php echo basename($_SERVER['PHP_SELF']) == 'ordens.php' ? 'bg-primary' : ''; ?>" href="ordens.php">
            <i class="bi bi-receipt me-2"></i> Ordens de Serviço
        </a>
        
        <!-- Notas -->
        <a class="nav-link text-white <?php echo basename($_SERVER['PHP_SELF']) == 'notas.php' ? 'bg-primary' : ''; ?>" href="notas.php">
            <i class="bi bi-file-text me-2"></i> Notas
        </a>
        
        <!-- Controle de Gastos -->
        <a class="nav-link text-white <?php echo basename($_SERVER['PHP_SELF']) == 'gastos.php' ? 'bg-primary' : ''; ?>" href="gastos.php">
            <i class="bi bi-cash-coin me-2"></i> Controle de Gastos
        </a>
        
        <!-- Relatórios -->
        <a class="nav-link text-white <?php echo basename($_SERVER['PHP_SELF']) == 'relatorios.php' ? 'bg-primary' : ''; ?>" href="relatorios.php">
            <i class="bi bi-graph-up me-2"></i> Relatórios
        </a>
        
        <hr>
        
        <!-- Sair -->
        <a class="nav-link text-white" href="logout.php">
            <i class="bi bi-box-arrow-right me-2"></i> Sair
        </a>
    </nav>
    
    <!-- Informações do Sistema -->
    <div class="p-3 border-top border-secondary">
        <small class="text-muted d-block">
            <i class="bi bi-person-circle me-1"></i>
            <?php echo $_SESSION['usuario_nome'] ?? 'Usuário'; ?>
        </small>
        <small class="text-muted d-block mt-1">
            <i class="bi bi-shield-check me-1"></i>
            <?php echo $_SESSION['usuario_nivel'] ?? 'N/A'; ?>
        </small>
        <small class="text-muted d-block mt-2">
            Sistema v2.0
        </small>
    </div>
</div>

<style>
    /* Estilos para melhorar a sidebar */
    .nav-link {
        border-radius: 5px;
        margin-bottom: 3px;
        padding: 10px 15px;
        transition: all 0.3s;
    }
    
    .nav-link:hover {
        background-color: rgba(255, 255, 255, 0.1) !important;
    }
    
    .nav-link.active {
        background-color: #0d6efd !important;
        font-weight: 500;
    }
    
    .nav-link .badge {
        font-size: 0.7rem;
        padding: 3px 6px;
    }
    
    .nav-link i {
        width: 20px;
        text-align: center;
    }
</style>