<?php
// gastos.php
require_once 'config.php';
verificarLogin();

$conn = conectarBanco();
$acao = $_GET['acao'] ?? 'listar';

// Processar ações
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['salvar_gasto'])) {
        $tipo = $_POST['tipo'];
        $descricao = $_POST['descricao'];
        $valor = str_replace(',', '.', str_replace('.', '', $_POST['valor']));
        $data_gasto = $_POST['data_gasto'];
        $tipo_pagamento_id = $_POST['tipo_pagamento_id'];
        $observacoes = $_POST['observacoes'];
        
        $stmt = $conn->prepare("INSERT INTO gastos (tipo, descricao, valor, data_gasto, tipo_pagamento_id, observacoes) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("ssdsis", $tipo, $descricao, $valor, $data_gasto, $tipo_pagamento_id, $observacoes);
        
        if ($stmt->execute()) {
            header('Location: gastos.php?msg=sucesso');
            exit();
        }
    } elseif (isset($_POST['excluir_gasto'])) {
        $id = $_POST['id'];
        $stmt = $conn->prepare("DELETE FROM gastos WHERE id=?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        header('Location: gastos.php?msg=excluido');
        exit();
    }
}

// Listar gastos
$gastos = [];
$filtro_tipo = $_GET['tipo'] ?? '';
$filtro_mes = $_GET['mes'] ?? date('Y-m');

$query = "
    SELECT g.*, tp.nome as pagamento_nome
    FROM gastos g
    LEFT JOIN tipos_pagamento tp ON g.tipo_pagamento_id = tp.id
    WHERE 1=1
";

if ($filtro_tipo) {
    $query .= " AND g.tipo = '$filtro_tipo'";
}

if ($filtro_mes) {
    $query .= " AND DATE_FORMAT(g.data_gasto, '%Y-%m') = '$filtro_mes'";
}

$query .= " ORDER BY g.data_gasto DESC";

$result = $conn->query($query);
while ($row = $result->fetch_assoc()) {
    $gastos[] = $row;
}

// Buscar tipos de pagamento
$tipos_pagamento = $conn->query("SELECT * FROM tipos_pagamento WHERE ativo = 1");

// Calcular totais
$total_copiadora = $conn->query("SELECT SUM(valor) as total FROM gastos WHERE tipo = 'copiadora' AND DATE_FORMAT(data_gasto, '%Y-%m') = '$filtro_mes'")->fetch_assoc()['total'];
$total_savio = $conn->query("SELECT SUM(valor) as total FROM gastos WHERE tipo = 'savio' AND DATE_FORMAT(data_gasto, '%Y-%m') = '$filtro_mes'")->fetch_assoc()['total'];
$total_copiadora = $total_copiadora ?: 0;
$total_savio = $total_savio ?: 0;
$total_geral = $total_copiadora + $total_savio;
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Controle de Gastos - Copiadora Central</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css">
</head>
<body>
    <?php include 'navbar.php'; ?>
    
    <div class="container-fluid mt-4">
        <div class="row">
            <?php include 'sidebar.php'; ?>
            
            <div class="col-md-10">
                <h2>Controle de Gastos</h2>
                
                <?php if ($acao === 'listar'): ?>
                    <div class="mb-3">
                        <a href="gastos.php?acao=novo" class="btn btn-primary">
                            <i class="bi bi-plus-circle me-2"></i> Novo Gasto
                        </a>
                        <button class="btn btn-secondary" onclick="window.print()">
                            <i class="bi bi-printer me-2"></i> Imprimir
                        </button>
                    </div>
                    
                    <!-- Filtros -->
                    <div class="card mb-3">
                        <div class="card-header">
                            <h5>Filtros</h5>
                        </div>
                        <div class="card-body">
                            <form method="GET" class="row">
                                <div class="col-md-4">
                                    <label for="tipo" class="form-label">Tipo de Gasto</label>
                                    <select class="form-select" id="tipo" name="tipo">
                                        <option value="">Todos os Tipos</option>
                                        <option value="copiadora" <?php echo $filtro_tipo === 'copiadora' ? 'selected' : ''; ?>>Copiadora</option>
                                        <option value="savio" <?php echo $filtro_tipo === 'savio' ? 'selected' : ''; ?>>Savio</option>
                                    </select>
                                </div>
                                <div class="col-md-4">
                                    <label for="mes" class="form-label">Mês/Ano</label>
                                    <input type="month" class="form-control" id="mes" name="mes" 
                                           value="<?php echo $filtro_mes; ?>">
                                </div>
                                <div class="col-md-4 d-flex align-items-end">
                                    <button type="submit" class="btn btn-primary me-2">
                                        <i class="bi bi-filter"></i> Filtrar
                                    </button>
                                    <a href="gastos.php" class="btn btn-secondary">Limpar</a>
                                </div>
                            </form>
                        </div>
                    </div>
                    
                    <?php if (isset($_GET['msg'])): ?>
                        <div class="alert alert-success">
                            <?php 
                                switch($_GET['msg']) {
                                    case 'sucesso': echo 'Gasto registrado com sucesso!'; break;
                                    case 'excluido': echo 'Gasto excluído com sucesso!'; break;
                                }
                            ?>
                        </div>
                    <?php endif; ?>
                    
                    <!-- Resumo -->
                    <div class="row mb-3">
                        <div class="col-md-4">
                            <div class="card bg-danger text-white">
                                <div class="card-body">
                                    <h6>Gastos Copiadora</h6>
                                    <h3><?php echo formatarMoeda($total_copiadora); ?></h3>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="card bg-warning text-white">
                                <div class="card-body">
                                    <h6>Gastos Savio</h6>
                                    <h3><?php echo formatarMoeda($total_savio); ?></h3>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="card bg-dark text-white">
                                <div class="card-body">
                                    <h6>Total Geral</h6>
                                    <h3><?php echo formatarMoeda($total_geral); ?></h3>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Lista de Gastos -->
                    <div class="card">
                        <div class="card-header">
                            <h5>Registro de Gastos</h5>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-striped table-hover">
                                    <thead>
                                        <tr>
                                            <th>Data</th>
                                            <th>Tipo</th>
                                            <th>Descrição</th>
                                            <th>Valor</th>
                                            <th>Pagamento</th>
                                            <th>Observações</th>
                                            <th>Ações</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($gastos as $gasto): ?>
                                            <tr>
                                                <td><?php echo formatarData($gasto['data_gasto']); ?></td>
                                                <td>
                                                    <span class="badge bg-<?php echo $gasto['tipo'] === 'copiadora' ? 'danger' : 'warning'; ?>">
                                                        <?php echo $gasto['tipo'] === 'copiadora' ? 'Copiadora' : 'Savio'; ?>
                                                    </span>
                                                </td>
                                                <td><?php echo htmlspecialchars($gasto['descricao']); ?></td>
                                                <td><?php echo formatarMoeda($gasto['valor']); ?></td>
                                                <td><?php echo htmlspecialchars($gasto['pagamento_nome']); ?></td>
                                                <td><?php echo htmlspecialchars(substr($gasto['observacoes'] ?? '', 0, 50)); ?></td>
                                                <td>
                                                    <button class="btn btn-sm btn-danger" data-bs-toggle="modal" data-bs-target="#modalExcluir<?php echo $gasto['id']; ?>">
                                                        <i class="bi bi-trash"></i>
                                                    </button>
                                                    
                                                    <!-- Modal de Exclusão -->
                                                    <div class="modal fade" id="modalExcluir<?php echo $gasto['id']; ?>" tabindex="-1">
                                                        <div class="modal-dialog">
                                                            <div class="modal-content">
                                                                <div class="modal-header">
                                                                    <h5 class="modal-title">Confirmar Exclusão</h5>
                                                                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                                                </div>
                                                                <div class="modal-body">
                                                                    Tem certeza que deseja excluir este gasto?
                                                                </div>
                                                                <div class="modal-footer">
                                                                    <form method="POST" style="display: inline;">
                                                                        <input type="hidden" name="id" value="<?php echo $gasto['id']; ?>">
                                                                        <button type="submit" name="excluir_gasto" class="btn btn-danger">Excluir</button>
                                                                    </form>
                                                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
                
                <?php if ($acao === 'novo'): ?>
                    <div class="card">
                        <div class="card-header">
                            <h5>Registrar Novo Gasto</h5>
                        </div>
                        <div class="card-body">
                            <form method="POST">
                                <div class="row mb-3">
                                    <div class="col-md-6">
                                        <label for="tipo" class="form-label">Tipo de Gasto *</label>
                                        <select class="form-select" id="tipo" name="tipo" required>
                                            <option value="">Selecione...</option>
                                            <option value="copiadora">Copiadora</option>
                                            <option value="savio">Savio</option>
                                        </select>
                                    </div>
                                    <div class="col-md-6">
                                        <label for="data_gasto" class="form-label">Data do Gasto *</label>
                                        <input type="date" class="form-control" id="data_gasto" name="data_gasto" 
                                               value="<?php echo date('Y-m-d'); ?>" required>
                                    </div>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="descricao" class="form-label">Descrição *</label>
                                    <input type="text" class="form-control" id="descricao" name="descricao" 
                                           placeholder="Ex: Compra de papel A4, Manutenção da impressora, etc." required>
                                </div>
                                
                                <div class="row mb-3">
                                    <div class="col-md-6">
                                        <label for="valor" class="form-label">Valor (R$) *</label>
                                        <input type="text" class="form-control" id="valor" name="valor" required>
                                    </div>
                                    <div class="col-md-6">
                                        <label for="tipo_pagamento_id" class="form-label">Forma de Pagamento *</label>
                                        <select class="form-select" id="tipo_pagamento_id" name="tipo_pagamento_id" required>
                                            <option value="">Selecione...</option>
                                            <?php while ($tp = $tipos_pagamento->fetch_assoc()): ?>
                                                <option value="<?php echo $tp['id']; ?>"><?php echo htmlspecialchars($tp['nome']); ?></option>
                                            <?php endwhile; ?>
                                        </select>
                                    </div>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="observacoes" class="form-label">Observações</label>
                                    <textarea class="form-control" id="observacoes" name="observacoes" rows="3"></textarea>
                                </div>
                                
                                <div class="d-flex gap-2">
                                    <button type="submit" name="salvar_gasto" class="btn btn-primary">
                                        <i class="bi bi-save me-2"></i> Salvar
                                    </button>
                                    <a href="gastos.php" class="btn btn-secondary">Cancelar</a>
                                </div>
                            </form>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Máscara para valor monetário
        document.getElementById('valor')?.addEventListener('input', function(e) {
            let value = e.target.value.replace(/\D/g, '');
            value = (value / 100).toFixed(2) + '';
            value = value.replace('.', ',');
            value = value.replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1.');
            e.target.value = value;
        });
    </script>
</body>
</html>