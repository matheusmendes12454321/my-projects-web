<?php
// ordens.php
require_once 'config.php';
verificarLogin();

$conn = conectarBanco();
$acao = $_GET['acao'] ?? 'listar';

// Processar ações
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['salvar_ordem'])) {
        // Salvar ordem principal
        $cliente_id = $_POST['cliente_id'] == 'anonimo' ? NULL : $_POST['cliente_id'];
        $data_entrega = $_POST['data_entrega'];
        $tipo_pagamento_id = $_POST['tipo_pagamento_id'];
        $observacoes = $_POST['observacoes'];
        $desconto = str_replace(',', '.', str_replace('.', '', $_POST['desconto'] ?? '0'));
        
        // Calcular valores
        $total = 0;
        if (isset($_POST['servico_id'])) {
            foreach ($_POST['servico_id'] as $key => $servico_id) {
                $quantidade = $_POST['quantidade'][$key];
                $valor_unitario = str_replace(',', '.', str_replace('.', '', $_POST['valor_unitario'][$key]));
                $subtotal = $quantidade * $valor_unitario;
                $total += $subtotal;
            }
        }
        
        $valor_final = $total - $desconto;
        $valor_final = max(0, $valor_final); // Garantir que não seja negativo
        
        // Inserir ordem
        $stmt = $conn->prepare("INSERT INTO ordens_servico (cliente_id, data_entrega, tipo_pagamento_id, valor_total, desconto, valor_final, observacoes) VALUES (?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("ssiddds", $cliente_id, $data_entrega, $tipo_pagamento_id, $total, $desconto, $valor_final, $observacoes);
        
        if ($stmt->execute()) {
            $ordem_id = $conn->insert_id;
            
            // Inserir itens
            if (isset($_POST['servico_id'])) {
                foreach ($_POST['servico_id'] as $key => $servico_id) {
                    $quantidade = $_POST['quantidade'][$key];
                    $valor_unitario = str_replace(',', '.', str_replace('.', '', $_POST['valor_unitario'][$key]));
                    $subtotal = $quantidade * $valor_unitario;
                    
                    $stmt_item = $conn->prepare("INSERT INTO ordem_itens (ordem_id, servico_id, quantidade, valor_unitario, subtotal) VALUES (?, ?, ?, ?, ?)");
                    $stmt_item->bind_param("iiidd", $ordem_id, $servico_id, $quantidade, $valor_unitario, $subtotal);
                    $stmt_item->execute();
                }
            }
            
            header('Location: notas.php?ordem=' . $ordem_id);
            exit();
        }
    } elseif (isset($_POST['atualizar_status'])) {
        $id = $_POST['id'];
        $status = $_POST['status'];
        $status_pagamento = $_POST['status_pagamento'];
        
        $stmt = $conn->prepare("UPDATE ordens_servico SET status=?, status_pagamento=? WHERE id=?");
        $stmt->bind_param("ssi", $status, $status_pagamento, $id);
        $stmt->execute();
        
        header('Location: ordens.php?msg=status');
        exit();
    }
}

// Listar ordens
$ordens = [];
if ($acao === 'listar') {
    $query = "
        SELECT os.*, 
               c.nome as cliente_nome,
               c.tipo as cliente_tipo,
               tp.nome as pagamento_nome
        FROM ordens_servico os
        LEFT JOIN clientes c ON os.cliente_id = c.id
        LEFT JOIN tipos_pagamento tp ON os.tipo_pagamento_id = tp.id
        ORDER BY os.data_ordem DESC
    ";
    $result = $conn->query($query);
    while ($row = $result->fetch_assoc()) {
        $ordens[] = $row;
    }
}

// Buscar clientes para select
$clientes = $conn->query("SELECT id, nome, tipo FROM clientes ORDER BY nome");
$tipos_pagamento = $conn->query("SELECT * FROM tipos_pagamento WHERE ativo = 1");
$servicos = $conn->query("SELECT * FROM servicos WHERE ativo = 1 ORDER BY nome");
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ordens de Serviço - Copiadora Central</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css">
    <style>
        .item-servico {
            background: #f8f9fa;
            border-radius: 5px;
            padding: 15px;
            margin-bottom: 10px;
        }
        .total-box {
            background: #e7f3ff;
            border-radius: 5px;
            padding: 20px;
            font-size: 1.2em;
            font-weight: bold;
        }
        .servico-header {
            background: #e9ecef;
            padding: 10px;
            border-radius: 5px;
            margin-bottom: 10px;
            font-weight: bold;
        }
    </style>
</head>
<body>
    <?php include 'navbar.php'; ?>
    
    <div class="container-fluid mt-4">
        <div class="row">
            <?php include 'sidebar.php'; ?>
            
            <div class="col-md-10">
                <h2>Ordens de Serviço</h2>
                
                <?php if ($acao === 'listar'): ?>
                    <div class="mb-3">
                        <a href="ordens.php?acao=nova" class="btn btn-primary">
                            <i class="bi bi-plus-circle me-2"></i> Nova Ordem
                        </a>
                    </div>
                    
                    <?php if (isset($_GET['msg'])): ?>
                        <div class="alert alert-success">
                            Status atualizado com sucesso!
                        </div>
                    <?php endif; ?>
                    
                    <div class="card">
                        <div class="card-header">
                            <h5>Todas as Ordens</h5>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-striped table-hover">
                                    <thead>
                                        <tr>
                                            <th>ID</th>
                                            <th>Cliente</th>
                                            <th>Data</th>
                                            <th>Entrega</th>
                                            <th>Valor Total</th>
                                            <th>Status</th>
                                            <th>Pagamento</th>
                                            <th>Ações</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($ordens as $ordem): ?>
                                            <tr>
                                                <td><?php echo $ordem['id']; ?></td>
                                                <td>
                                                    <?php if ($ordem['cliente_tipo'] === 'anonimo'): ?>
                                                        <span class="badge bg-warning">Anônimo</span>
                                                    <?php else: ?>
                                                        <?php echo htmlspecialchars($ordem['cliente_nome'] ?? 'N/A'); ?>
                                                    <?php endif; ?>
                                                </td>
                                                <td><?php echo formatarData($ordem['data_ordem'], 'd/m/Y H:i'); ?></td>
                                                <td><?php echo formatarData($ordem['data_entrega']); ?></td>
                                                <td><?php echo formatarMoeda($ordem['valor_final']); ?></td>
                                                <td>
                                                    <span class="badge bg-<?php 
                                                        switch($ordem['status']) {
                                                            case 'pendente': echo 'warning'; break;
                                                            case 'em_andamento': echo 'info'; break;
                                                            case 'concluido': echo 'success'; break;
                                                            case 'entregue': echo 'primary'; break;
                                                            case 'cancelado': echo 'danger'; break;
                                                        }
                                                    ?>">
                                                        <?php echo ucfirst($ordem['status']); ?>
                                                    </span>
                                                    <br>
                                                    <span class="badge bg-<?php echo $ordem['status_pagamento'] === 'pago' ? 'success' : 'danger'; ?>">
                                                        <?php echo $ordem['status_pagamento'] === 'pago' ? 'Pago' : 'Pendente'; ?>
                                                    </span>
                                                </td>
                                                <td><?php echo htmlspecialchars($ordem['pagamento_nome']); ?></td>
                                                <td>
                                                    <a href="notas.php?ordem=<?php echo $ordem['id']; ?>" class="btn btn-sm btn-info" target="_blank">
                                                        <i class="bi bi-receipt"></i>
                                                    </a>
                                                    <button class="btn btn-sm btn-warning" data-bs-toggle="modal" data-bs-target="#modalStatus<?php echo $ordem['id']; ?>">
                                                        <i class="bi bi-pencil"></i>
                                                    </button>
                                                </td>
                                            </tr>
                                            
                                            <!-- Modal de Status -->
                                            <div class="modal fade" id="modalStatus<?php echo $ordem['id']; ?>" tabindex="-1">
                                                <div class="modal-dialog">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <h5 class="modal-title">Alterar Status - Ordem #<?php echo $ordem['id']; ?></h5>
                                                            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                                        </div>
                                                        <form method="POST">
                                                            <div class="modal-body">
                                                                <input type="hidden" name="id" value="<?php echo $ordem['id']; ?>">
                                                                
                                                                <div class="mb-3">
                                                                    <label for="status<?php echo $ordem['id']; ?>" class="form-label">Status do Serviço</label>
                                                                    <select class="form-select" id="status<?php echo $ordem['id']; ?>" name="status">
                                                                        <option value="pendente" <?php echo $ordem['status'] === 'pendente' ? 'selected' : ''; ?>>Pendente</option>
                                                                        <option value="em_andamento" <?php echo $ordem['status'] === 'em_andamento' ? 'selected' : ''; ?>>Em Andamento</option>
                                                                        <option value="concluido" <?php echo $ordem['status'] === 'concluido' ? 'selected' : ''; ?>>Concluído</option>
                                                                        <option value="entregue" <?php echo $ordem['status'] === 'entregue' ? 'selected' : ''; ?>>Entregue</option>
                                                                        <option value="cancelado" <?php echo $ordem['status'] === 'cancelado' ? 'selected' : ''; ?>>Cancelado</option>
                                                                    </select>
                                                                </div>
                                                                
                                                                <div class="mb-3">
                                                                    <label for="status_pagamento<?php echo $ordem['id']; ?>" class="form-label">Status do Pagamento</label>
                                                                    <select class="form-select" id="status_pagamento<?php echo $ordem['id']; ?>" name="status_pagamento">
                                                                        <option value="pendente" <?php echo $ordem['status_pagamento'] === 'pendente' ? 'selected' : ''; ?>>Pendente</option>
                                                                        <option value="pago" <?php echo $ordem['status_pagamento'] === 'pago' ? 'selected' : ''; ?>>Pago</option>
                                                                    </select>
                                                                </div>
                                                            </div>
                                                            <div class="modal-footer">
                                                                <button type="submit" name="atualizar_status" class="btn btn-primary">Salvar</button>
                                                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                                                            </div>
                                                        </form>
                                                    </div>
                                                </div>
                                            </div>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
                
                <?php if ($acao === 'nova'): ?>
                    <div class="card">
                        <div class="card-header">
                            <h5>Nova Ordem de Serviço</h5>
                        </div>
                        <div class="card-body">
                            <form method="POST" id="formOrdem">
                                <div class="row mb-3">
                                    <div class="col-md-6">
                                        <label for="cliente_id" class="form-label">Cliente</label>
                                        <select class="form-select" id="cliente_id" name="cliente_id" required>
                                            <option value="">Selecione um cliente...</option>
                                            <option value="anonimo">Cliente Anônimo</option>
                                            <?php 
                                            if ($clientes->num_rows > 0):
                                                while ($cliente = $clientes->fetch_assoc()): ?>
                                                    <option value="<?php echo $cliente['id']; ?>">
                                                        <?php echo htmlspecialchars($cliente['nome']); ?>
                                                        <?php if ($cliente['tipo'] === 'anonimo'): ?> (Anônimo)<?php endif; ?>
                                                    </option>
                                                <?php endwhile; 
                                            else: ?>
                                                <option value="">Nenhum cliente cadastrado</option>
                                            <?php endif; ?>
                                        </select>
                                    </div>
                                    <div class="col-md-6">
                                        <label for="data_entrega" class="form-label">Data de Entrega</label>
                                        <input type="date" class="form-control" id="data_entrega" name="data_entrega" required
                                               value="<?php echo date('Y-m-d', strtotime('+1 day')); ?>">
                                    </div>
                                </div>
                                
                                <div class="row mb-4">
                                    <div class="col-md-6">
                                        <label for="tipo_pagamento_id" class="form-label">Tipo de Pagamento</label>
                                        <select class="form-select" id="tipo_pagamento_id" name="tipo_pagamento_id" required>
                                            <option value="">Selecione...</option>
                                            <?php 
                                            if ($tipos_pagamento->num_rows > 0):
                                                while ($tp = $tipos_pagamento->fetch_assoc()): ?>
                                                    <option value="<?php echo $tp['id']; ?>"><?php echo htmlspecialchars($tp['nome']); ?></option>
                                                <?php endwhile;
                                            else: ?>
                                                <option value="">Nenhum tipo de pagamento cadastrado</option>
                                            <?php endif; ?>
                                        </select>
                                    </div>
                                    <div class="col-md-6">
                                        <label for="desconto" class="form-label">Desconto (R$)</label>
                                        <input type="text" class="form-control" id="desconto" name="desconto" value="0,00">
                                    </div>
                                </div>
                                
                                <div class="servico-header">
                                    <h5 class="mb-0">Serviços</h5>
                                    <small>Adicione os serviços para esta ordem</small>
                                </div>
                                
                                <div id="servicos-container">
                                    <!-- Serviços serão adicionados aqui via JavaScript -->
                                </div>
                                
                                <div class="mb-3">
                                    <button type="button" class="btn btn-success" onclick="adicionarServico()">
                                        <i class="bi bi-plus-circle me-2"></i> Adicionar Serviço
                                    </button>
                                </div>
                                
                                <div class="row mb-3">
                                    <div class="col-md-8">
                                        <label for="observacoes" class="form-label">Observações</label>
                                        <textarea class="form-control" id="observacoes" name="observacoes" rows="3" placeholder="Observações sobre a ordem..."></textarea>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="total-box text-center">
                                            <div>Total: <span id="total-geral">R$ 0,00</span></div>
                                            <div>Desconto: <span id="total-desconto">R$ 0,00</span></div>
                                            <hr>
                                            <div class="text-success">Valor Final: <span id="valor-final">R$ 0,00</span></div>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="d-flex gap-2">
                                    <button type="submit" name="salvar_ordem" class="btn btn-primary">
                                        <i class="bi bi-save me-2"></i> Salvar e Gerar Nota
                                    </button>
                                    <a href="ordens.php" class="btn btn-secondary">Cancelar</a>
                                </div>
                            </form>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Dados dos serviços
        const servicos = [
            <?php 
            if ($servicos->num_rows > 0) {
                $servicos->data_seek(0);
                while ($servico = $servicos->fetch_assoc()): 
            ?>
            {
                id: <?php echo $servico['id']; ?>,
                nome: "<?php echo addslashes($servico['nome']); ?>",
                valor: <?php echo $servico['valor']; ?>
            },
            <?php 
                endwhile;
            } else {
                echo '{id: 0, nome: "Nenhum serviço cadastrado", valor: 0}';
            }
            ?>
        ];
        
        let contadorServicos = 0;
        
        function adicionarServico(servicoId = '', quantidade = 1, valorUnitario = 0) {
            const container = document.getElementById('servicos-container');
            const index = contadorServicos++;
            
            const servicoHtml = `
                <div class="item-servico" id="servico-${index}">
                    <div class="row">
                        <div class="col-md-4">
                            <label class="form-label">Serviço</label>
                            <select class="form-select servico-select" name="servico_id[]" onchange="atualizarValor(${index})" required>
                                <option value="">Selecione um serviço...</option>
                                ${servicos.map(s => `
                                    <option value="${s.id}" ${servicoId == s.id ? 'selected' : ''}>
                                        ${s.nome} - R$ ${s.valor.toFixed(2).replace('.', ',')}
                                    </option>
                                `).join('')}
                            </select>
                        </div>
                        <div class="col-md-2">
                            <label class="form-label">Quantidade</label>
                            <input type="number" class="form-control quantidade" name="quantidade[]" 
                                   value="${quantidade}" min="1" onchange="calcularSubtotal(${index})" oninput="calcularSubtotal(${index})" required>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label">Valor Unitário (R$)</label>
                            <input type="text" class="form-control valor-unitario" name="valor_unitario[]" 
                                   value="${valorUnitario ? valorUnitario.toFixed(2).replace('.', ',') : '0,00'}" 
                                   onchange="calcularSubtotal(${index})" oninput="calcularSubtotal(${index})" required>
                        </div>
                        <div class="col-md-2">
                            <label class="form-label">Subtotal</label>
                            <input type="text" class="form-control subtotal" readonly 
                                   value="R$ 0,00">
                        </div>
                        <div class="col-md-1 d-flex align-items-end">
                            <button type="button" class="btn btn-danger btn-sm" onclick="removerServico(${index})">
                                <i class="bi bi-trash"></i>
                            </button>
                        </div>
                    </div>
                </div>
            `;
            
            container.insertAdjacentHTML('beforeend', servicoHtml);
            
            // Adicionar máscara ao campo de valor unitário
            const valorInput = document.querySelector(`#servico-${index} .valor-unitario`);
            if (valorInput) {
                valorInput.addEventListener('input', function(e) {
                    let value = e.target.value.replace(/\D/g, '');
                    value = (value / 100).toFixed(2) + '';
                    value = value.replace('.', ',');
                    value = value.replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1.');
                    e.target.value = value;
                    calcularSubtotal(index);
                });
            }
            
            if (servicoId) {
                atualizarValor(index);
            } else {
                calcularSubtotal(index);
            }
        }
        
        function removerServico(index) {
            const elemento = document.getElementById(`servico-${index}`);
            if (elemento) {
                elemento.remove();
                calcularTotal();
            }
        }
        
        function atualizarValor(index) {
            const select = document.querySelector(`#servico-${index} .servico-select`);
            if (!select) return;
            
            const servicoId = select.value;
            const servico = servicos.find(s => s.id == servicoId);
            
            if (servico) {
                const valorInput = document.querySelector(`#servico-${index} .valor-unitario`);
                if (valorInput) {
                    valorInput.value = servico.valor.toFixed(2).replace('.', ',');
                    calcularSubtotal(index);
                }
            }
        }
        
        function calcularSubtotal(index) {
            const quantidadeInput = document.querySelector(`#servico-${index} .quantidade`);
            const valorInput = document.querySelector(`#servico-${index} .valor-unitario`);
            const subtotalInput = document.querySelector(`#servico-${index} .subtotal`);
            
            if (!quantidadeInput || !valorInput || !subtotalInput) return;
            
            const quantidade = parseFloat(quantidadeInput.value) || 0;
            const valorUnitario = parseFloat(
                valorInput.value.replace(/\./g, '').replace(',', '.')
            ) || 0;
            
            const subtotal = quantidade * valorUnitario;
            subtotalInput.value = 'R$ ' + subtotal.toFixed(2).replace('.', ',');
            
            calcularTotal();
        }
        
        function calcularTotal() {
            let total = 0;
            
            document.querySelectorAll('.subtotal').forEach(input => {
                const valor = parseFloat(input.value.replace('R$ ', '').replace('.', '').replace(',', '.')) || 0;
                total += valor;
            });
            
            const descontoInput = document.getElementById('desconto');
            const desconto = parseFloat(
                descontoInput.value.replace(/\./g, '').replace(',', '.')
            ) || 0;
            
            const valorFinal = total - desconto;
            
            document.getElementById('total-geral').textContent = 'R$ ' + total.toFixed(2).replace('.', ',');
            document.getElementById('total-desconto').textContent = 'R$ ' + desconto.toFixed(2).replace('.', ',');
            document.getElementById('valor-final').textContent = 'R$ ' + Math.max(0, valorFinal).toFixed(2).replace('.', ',');
        }
        
        // Adicionar um serviço ao carregar a página
        document.addEventListener('DOMContentLoaded', function() {
            adicionarServico();
            
            // Adicionar máscara para desconto
            const descontoInput = document.getElementById('desconto');
            if (descontoInput) {
                descontoInput.addEventListener('input', function(e) {
                    let value = e.target.value.replace(/\D/g, '');
                    value = (value / 100).toFixed(2) + '';
                    value = value.replace('.', ',');
                    value = value.replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1.');
                    e.target.value = value;
                    calcularTotal();
                });
            }
            
            // Adicionar máscara para campos de valor ao carregar
            document.querySelectorAll('.valor-unitario').forEach(input => {
                input.addEventListener('input', function(e) {
                    let value = e.target.value.replace(/\D/g, '');
                    value = (value / 100).toFixed(2) + '';
                    value = value.replace('.', ',');
                    value = value.replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1.');
                    e.target.value = value;
                });
            });
            
            // Calcular total inicial
            calcularTotal();
        });
        
        // Validar formulário antes de enviar
        document.getElementById('formOrdem')?.addEventListener('submit', function(e) {
            // Verificar se há pelo menos um serviço
            const servicosCount = document.querySelectorAll('.item-servico').length;
            if (servicosCount === 0) {
                e.preventDefault();
                alert('Adicione pelo menos um serviço!');
                return false;
            }
            
            // Verificar se todos os serviços estão preenchidos
            let todosPreenchidos = true;
            document.querySelectorAll('.servico-select').forEach(select => {
                if (!select.value) {
                    todosPreenchidos = false;
                    select.classList.add('is-invalid');
                } else {
                    select.classList.remove('is-invalid');
                }
            });
            
            if (!todosPreenchidos) {
                e.preventDefault();
                alert('Preencha todos os serviços!');
                return false;
            }
            
            return true;
        });
    </script>
</body>
</html>