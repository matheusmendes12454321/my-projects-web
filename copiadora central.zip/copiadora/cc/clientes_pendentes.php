<?php
// clientes_pendentes.php
require_once 'config.php';
verificarLogin();

$conn = conectarBanco();

// Inicializar variáveis
$clientes_pendentes = [];
$total_pendente = 0;
$filtro_nome = $_GET['nome'] ?? '';
$filtro_dias = $_GET['dias'] ?? '';
$filtro_valor_min = $_GET['valor_min'] ?? '';
$filtro_valor_max = $_GET['valor_max'] ?? '';

// Construir consulta
$query = "
    SELECT 
        c.id,
        c.nome,
        c.cpf_cnpj,
        c.telefone,
        c.email,
        COUNT(os.id) as total_ordens_pendentes,
        SUM(os.valor_final) as total_valor_pendente,
        MAX(os.data_ordem) as ultima_ordem,
        MIN(os.data_ordem) as primeira_ordem_pendente,
        DATEDIFF(CURDATE(), MAX(os.data_ordem)) as dias_atraso
    FROM clientes c
    INNER JOIN ordens_servico os ON c.id = os.cliente_id
    WHERE os.status_pagamento = 'pendente'
    AND os.status NOT IN ('cancelado')
    AND c.tipo = 'normal'
";

// Aplicar filtros
$params = [];
$types = '';

if (!empty($filtro_nome)) {
    $query .= " AND c.nome LIKE ?";
    $params[] = "%$filtro_nome%";
    $types .= "s";
}

if (!empty($filtro_dias) && is_numeric($filtro_dias)) {
    $query .= " AND DATEDIFF(CURDATE(), os.data_ordem) > ?";
    $params[] = $filtro_dias;
    $types .= "i";
}

if (!empty($filtro_valor_min) && is_numeric($filtro_valor_min)) {
    $query .= " AND os.valor_final >= ?";
    $params[] = $filtro_valor_min;
    $types .= "d";
}

if (!empty($filtro_valor_max) && is_numeric($filtro_valor_max)) {
    $query .= " AND os.valor_final <= ?";
    $params[] = $filtro_valor_max;
    $types .= "d";
}

$query .= " GROUP BY c.id HAVING total_valor_pendente > 0";

// Ordenação
$ordenacao = $_GET['ordenar'] ?? 'total_valor_pendente';
$direcao = $_GET['direcao'] ?? 'DESC';
$query .= " ORDER BY $ordenacao $direcao";

// Preparar e executar consulta
if (empty($params)) {
    $result = $conn->query($query);
} else {
    $stmt = $conn->prepare($query);
    $stmt->bind_param($types, ...$params);
    $stmt->execute();
    $result = $stmt->get_result();
}

while ($row = $result->fetch_assoc()) {
    $clientes_pendentes[] = $row;
    $total_pendente += $row['total_valor_pendente'];
}

// Buscar totais para dashboard
$total_clientes_pendentes = count($clientes_pendentes);
$maior_valor_pendente = 0;
$cliente_maior_pendente = '';

foreach ($clientes_pendentes as $cliente) {
    if ($cliente['total_valor_pendente'] > $maior_valor_pendente) {
        $maior_valor_pendente = $cliente['total_valor_pendente'];
        $cliente_maior_pendente = $cliente['nome'];
    }
}

// Buscar ordens pendentes por cliente para detalhamento
$ordens_por_cliente = [];
foreach ($clientes_pendentes as $cliente) {
    $cliente_id = $cliente['id'];
    $ordens_query = "
        SELECT os.id, os.data_ordem, os.valor_final, os.observacoes, os.status
        FROM ordens_servico os
        WHERE os.cliente_id = $cliente_id 
        AND os.status_pagamento = 'pendente'
        AND os.status NOT IN ('cancelado')
        ORDER BY os.data_ordem DESC
    ";
    
    $ordens_result = $conn->query($ordens_query);
    $ordens_por_cliente[$cliente_id] = $ordens_result->fetch_all(MYSQLI_ASSOC);
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Clientes com Pagamentos Pendentes | Copiadora Central</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.11.5/css/dataTables.bootstrap5.min.css">
    <style>
        :root {
            --primary-color: #4361ee;
            --warning-color: #f59e0b;
            --danger-color: #ef4444;
            --success-color: #10b981;
        }
        
        .card-stat {
            border-radius: 10px;
            transition: transform 0.3s;
            border: none;
        }
        
        .card-stat:hover {
            transform: translateY(-5px);
        }
        
        .badge-pendente {
            background: var(--warning-color);
            color: white;
        }
        
        .badge-atrasado {
            background: var(--danger-color);
            color: white;
        }
        
        .badge-normal {
            background: var(--success-color);
            color: white;
        }
        
        .cliente-row {
            cursor: pointer;
            transition: background-color 0.2s;
        }
        
        .cliente-row:hover {
            background-color: #f8f9fa;
        }
        
        .table-hover tbody tr:hover {
            background-color: rgba(67, 97, 238, 0.05);
        }
        
        .valor-pendente {
            font-weight: bold;
            color: var(--danger-color);
        }
        
        .filtros-avancados {
            background: #f8f9fa;
            border-radius: 8px;
            padding: 15px;
            margin-bottom: 20px;
        }
        
        .btn-export {
            border-radius: 8px;
            padding: 8px 20px;
            font-weight: 500;
        }
        
        .status-indicator {
            width: 12px;
            height: 12px;
            border-radius: 50%;
            display: inline-block;
            margin-right: 5px;
        }
        
        .status-atrasado {
            background-color: var(--danger-color);
        }
        
        .status-pendente {
            background-color: var(--warning-color);
        }
        
        .status-normal {
            background-color: var(--success-color);
        }
        
        .accordion-button:not(.collapsed) {
            background-color: rgba(67, 97, 238, 0.1);
            color: var(--primary-color);
        }
        
        .btn-acoes {
            padding: 5px 10px;
            font-size: 0.8rem;
        }
        
        @media print {
            .no-print {
                display: none !important;
            }
            
            .card {
                border: none !important;
                box-shadow: none !important;
            }
        }
    </style>
</head>
<body>
    <?php include 'navbar.php'; ?>
    
    <div class="container-fluid mt-4">
        <div class="row">
            <?php include 'sidebar.php'; ?>
            
            <div class="col-md-10">
                <!-- Cabeçalho -->
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <div>
                        <h2><i class="bi bi-clock-history me-2"></i>Clientes com Pagamentos Pendentes</h2>
                        <p class="text-muted">Gerencie e acompanhe os pagamentos em aberto</p>
                    </div>
                    <div class="no-print">
                        <button onclick="window.print()" class="btn btn-outline-secondary me-2">
                            <i class="bi bi-printer"></i> Imprimir
                        </button>
                        <a href="relatorio_pendentes.php" class="btn btn-primary">
                            <i class="bi bi-file-earmark-text"></i> Relatório Completo
                        </a>
                    </div>
                </div>
                
                <!-- Cards de Estatísticas -->
                <div class="row mb-4">
                    <div class="col-md-3">
                        <div class="card card-stat bg-warning text-white">
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-center">
                                    <div>
                                        <h6 class="card-title">Clientes Pendentes</h6>
                                        <h3><?php echo $total_clientes_pendentes; ?></h3>
                                        <small><?php echo count($clientes_pendentes); ?> registros</small>
                                    </div>
                                    <i class="bi bi-people fs-1"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-md-3">
                        <div class="card card-stat bg-danger text-white">
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-center">
                                    <div>
                                        <h6 class="card-title">Total Pendente</h6>
                                        <h3><?php echo formatarMoeda($total_pendente); ?></h3>
                                        <small>Valor em aberto</small>
                                    </div>
                                    <i class="bi bi-cash-stack fs-1"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-md-3">
                        <div class="card card-stat bg-info text-white">
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-center">
                                    <div>
                                        <h6 class="card-title">Maior Pendência</h6>
                                        <h4><?php echo formatarMoeda($maior_valor_pendente); ?></h4>
                                        <small><?php echo substr($cliente_maior_pendente, 0, 20) . '...'; ?></small>
                                    </div>
                                    <i class="bi bi-exclamation-triangle fs-1"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-md-3">
                        <div class="card card-stat bg-primary text-white">
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-center">
                
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Filtros -->
                <div class="card mb-4 no-print">
                    <div class="card-header">
                        <h5 class="mb-0">
                            <i class="bi bi-funnel me-2"></i>Filtros de Busca
                        </h5>
                    </div>
                    <div class="card-body">
                        <form method="GET" id="formFiltros">
                            <div class="row">
                                <div class="col-md-3">
                                    <label for="nome" class="form-label">Nome do Cliente</label>
                                    <input type="text" class="form-control" id="nome" name="nome" 
                                           value="<?php echo htmlspecialchars($filtro_nome); ?>"
                                           placeholder="Buscar por nome...">
                                </div>
                                
                                <div class="col-md-2">
                                    <label for="dias" class="form-label">Dias em Atraso</label>
                                    <input type="number" class="form-control" id="dias" name="dias" 
                                           value="<?php echo htmlspecialchars($filtro_dias); ?>"
                                           placeholder="Mais de X dias">
                                </div>
                                
                                <div class="col-md-2">
                                    <label for="valor_min" class="form-label">Valor Mínimo</label>
                                    <input type="number" class="form-control" id="valor_min" name="valor_min" 
                                           value="<?php echo htmlspecialchars($filtro_valor_min); ?>"
                                           placeholder="R$ 0,00" step="0.01">
                                </div>
                                
                                <div class="col-md-2">
                                    <label for="valor_max" class="form-label">Valor Máximo</label>
                                    <input type="number" class="form-control" id="valor_max" name="valor_max" 
                                           value="<?php echo htmlspecialchars($filtro_valor_max); ?>"
                                           placeholder="R$ 0,00" step="0.01">
                                </div>
                                
                                <div class="col-md-3 d-flex align-items-end">
                                    <div class="d-grid gap-2 w-100">
                                        <button type="submit" class="btn btn-primary">
                                            <i class="bi bi-search me-2"></i> Filtrar
                                        </button>
                                        <a href="clientes_pendentes.php" class="btn btn-secondary">Limpar Filtros</a>
                                    </div>
                                </div>
                            </div>
                            
                            <!-- Filtros Avançados (acordeão) -->
                            <div class="accordion mt-3" id="accordionFiltros">
                                <div class="accordion-item">
                                    <h2 class="accordion-header" id="headingFiltros">
                                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseFiltros">
                                            <i class="bi bi-gear me-2"></i> Filtros Avançados
                                        </button>
                                    </h2>
                                    <div id="collapseFiltros" class="accordion-collapse collapse" data-bs-parent="#accordionFiltros">
                                        <div class="accordion-body">
                                            <div class="row">
                                                <div class="col-md-3">
                                                    <label class="form-label">Ordenar por:</label>
                                                    <select class="form-select" name="ordenar">
                                                        <option value="total_valor_pendente" <?php echo $ordenacao == 'total_valor_pendente' ? 'selected' : ''; ?>>Valor Pendente</option>
                                                        <option value="dias_atraso" <?php echo $ordenacao == 'dias_atraso' ? 'selected' : ''; ?>>Dias em Atraso</option>
                                                        <option value="nome" <?php echo $ordenacao == 'nome' ? 'selected' : ''; ?>>Nome do Cliente</option>
                                                        <option value="ultima_ordem" <?php echo $ordenacao == 'ultima_ordem' ? 'selected' : ''; ?>>Data Última Ordem</option>
                                                    </select>
                                                </div>
                                                
                                                <div class="col-md-3">
                                                    <label class="form-label">Direção:</label>
                                                    <select class="form-select" name="direcao">
                                                        <option value="DESC" <?php echo $direcao == 'DESC' ? 'selected' : ''; ?>>Decrescente</option>
                                                        <option value="ASC" <?php echo $direcao == 'ASC' ? 'selected' : ''; ?>>Crescente</option>
                                                    </select>
                                                </div>
                                                
                                                <div class="col-md-3">
                                                    <label class="form-label">Status:</label>
                                                    <select class="form-select" name="status">
                                                        <option value="">Todos</option>
                                                        <option value="atrasado" <?php echo ($_GET['status'] ?? '') == 'atrasado' ? 'selected' : ''; ?>>Em Atraso</option>
                                                        <option value="pendente" <?php echo ($_GET['status'] ?? '') == 'pendente' ? 'selected' : ''; ?>>Pendente Normal</option>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
                
                <!-- Lista de Clientes com Pendências -->
                <div class="card">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <h5 class="mb-0">
                            <i class="bi bi-list-check me-2"></i>
                            Lista de Clientes com Pagamentos Pendentes
                            <span class="badge bg-danger ms-2"><?php echo count($clientes_pendentes); ?></span>
                        </h5>
                        <div class="no-print">
                            <button class="btn btn-sm btn-outline-success" onclick="marcarTodosComoPagos()">
                                <i class="bi bi-check-all"></i> Marcar Tudo como Pago
                            </button>
                        </div>
                    </div>
                    
                    <div class="card-body">
                        <?php if (empty($clientes_pendentes)): ?>
                            <div class="alert alert-info text-center">
                                <i class="bi bi-info-circle fs-4"></i>
                                <h5 class="mt-2">Nenhum cliente com pagamento pendente encontrado!</h5>
                                <p class="mb-0">Todos os pagamentos estão em dia ou os filtros aplicados não retornaram resultados.</p>
                            </div>
                        <?php else: ?>
                            <div class="table-responsive">
                                <table class="table table-hover" id="tabelaClientes">
                                    <thead class="table-light">
                                        <tr>
                                            <th width="30">
                                                <input type="checkbox" id="selectAll">
                                            </th>
                                            <th>Cliente</th>
                                            <th>Contato</th>
                                            <th>Ordens Pendentes</th>
                                            <th>Valor Total Pendente</th>
                                            <th>Última Ordem</th>
                                            <th>Dias em Atraso</th>
                                            <th>Status</th>
                                            <th class="no-print">Ações</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($clientes_pendentes as $cliente): ?>
                                            <?php
                                            // Determinar status baseado em dias de atraso
                                            $status = '';
                                            $status_class = '';
                                            $status_icon = '';
                                            
                                            if ($cliente['dias_atraso'] > 30) {
                                                $status = 'Crítico';
                                                $status_class = 'badge-atrasado';
                                                $status_icon = 'bi-exclamation-triangle';
                                            } elseif ($cliente['dias_atraso'] > 15) {
                                                $status = 'Atrasado';
                                                $status_class = 'badge-atrasado';
                                                $status_icon = 'bi-clock';
                                            } else {
                                                $status = 'Pendente';
                                                $status_class = 'badge-pendente';
                                                $status_icon = 'bi-clock-history';
                                            }
                                            ?>
                                            
                                            <tr class="cliente-row" data-bs-toggle="collapse" data-bs-target="#detalhesCliente<?php echo $cliente['id']; ?>">
                                                <td>
                                                    <input type="checkbox" class="cliente-checkbox" value="<?php echo $cliente['id']; ?>">
                                                </td>
                                                <td>
                                                    <strong><?php echo htmlspecialchars($cliente['nome']); ?></strong>
                                                    <?php if (!empty($cliente['cpf_cnpj'])): ?>
                                                        <br><small class="text-muted"><?php echo htmlspecialchars($cliente['cpf_cnpj']); ?></small>
                                                    <?php endif; ?>
                                                </td>
                                                <td>
                                                    <?php if (!empty($cliente['telefone'])): ?>
                                                        <div><i class="bi bi-telephone"></i> <?php echo htmlspecialchars($cliente['telefone']); ?></div>
                                                    <?php endif; ?>
                                                    <?php if (!empty($cliente['email'])): ?>
                                                        <div><i class="bi bi-envelope"></i> <?php echo htmlspecialchars($cliente['email']); ?></div>
                                                    <?php endif; ?>
                                                </td>
                                                <td>
                                                    <span class="badge bg-secondary"><?php echo $cliente['total_ordens_pendentes']; ?> ordens</span>
                                                </td>
                                                <td class="valor-pendente">
                                                    <?php echo formatarMoeda($cliente['total_valor_pendente']); ?>
                                                </td>
                                                <td>
                                                    <?php echo formatarData($cliente['ultima_ordem']); ?>
                                                    <br><small class="text-muted"><?php echo $cliente['dias_atraso']; ?> dias</small>
                                                </td>
                                                <td>
                                                    <div class="progress" style="height: 20px;">
                                                        <?php 
                                                        $progress_width = min($cliente['dias_atraso'], 100);
                                                        $progress_class = $cliente['dias_atraso'] > 30 ? 'bg-danger' : ($cliente['dias_atraso'] > 15 ? 'bg-warning' : 'bg-info');
                                                        ?>
                                                        <div class="progress-bar <?php echo $progress_class; ?>" 
                                                             style="width: <?php echo $progress_width; ?>%"
                                                             role="progressbar">
                                                            <?php echo $cliente['dias_atraso']; ?> dias
                                                        </div>
                                                    </div>
                                                </td>
                                                <td>
                                                    <span class="badge <?php echo $status_class; ?>">
                                                        <i class="bi <?php echo $status_icon; ?>"></i> <?php echo $status; ?>
                                                    </span>
                                                </td>
                                                <td class="no-print">
                                                    <div class="btn-group btn-group-sm" role="group">
                                                        <button class="btn btn-outline-primary" 
                                                                onclick="event.stopPropagation(); visualizarCliente(<?php echo $cliente['id']; ?>)"
                                                                title="Ver detalhes">
                                                            <i class="bi bi-eye"></i>
                                                        </button>
                                                        <button class="btn btn-outline-success" 
                                                                onclick="event.stopPropagation(); marcarComoPago(<?php echo $cliente['id']; ?>)"
                                                                title="Marcar como pago">
                                                            <i class="bi bi-check-circle"></i>
                                                        </button>
                                                        <button class="btn btn-outline-warning" 
                                                                onclick="event.stopPropagation(); enviarLembrete(<?php echo $cliente['id']; ?>)"
                                                                title="Enviar lembrete">
                                                            <i class="bi bi-envelope"></i>
                                                        </button>
                                                        <a href="ordens.php?cliente=<?php echo $cliente['id']; ?>&status_pendente=1" 
                                                           class="btn btn-outline-info"
                                                           title="Ver ordens">
                                                            <i class="bi bi-receipt"></i>
                                                        </a>
                                                    </div>
                                                </td>
                                            </tr>
                                            
                                            <!-- Linha de detalhes (collapse) -->
                                            <tr class="collapse-details">
                                                <td colspan="9" class="p-0">
                                                    <div class="collapse" id="detalhesCliente<?php echo $cliente['id']; ?>">
                                                        <div class="p-3 bg-light">
                                                            <h6><i class="bi bi-receipt me-2"></i>Ordens Pendentes deste Cliente</h6>
                                                            
                                                            <?php if (!empty($ordens_por_cliente[$cliente['id']])): ?>
                                                                <div class="table-responsive">
                                                                    <table class="table table-sm">
                                                                        <thead>
                                                                            <tr>
                                                                                <th># Ordem</th>
                                                                                <th>Data</th>
                                                                                <th>Valor</th>
                                                                                <th>Status</th>
                                                                                <th>Observações</th>
                                                                                <th class="no-print">Ações</th>
                                                                            </tr>
                                                                        </thead>
                                                                        <tbody>
                                                                            <?php foreach ($ordens_por_cliente[$cliente['id']] as $ordem): ?>
                                                                                <tr>
                                                                                    <td>#<?php echo str_pad($ordem['id'], 6, '0', STR_PAD_LEFT); ?></td>
                                                                                    <td><?php echo formatarData($ordem['data_ordem'], 'd/m/Y'); ?></td>
                                                                                    <td class="valor-pendente"><?php echo formatarMoeda($ordem['valor_final']); ?></td>
                                                                                    <td>
                                                                                        <span class="badge bg-warning"><?php echo ucfirst($ordem['status']); ?></span>
                                                                                    </td>
                                                                                    <td>
                                                                                        <?php echo !empty($ordem['observacoes']) ? substr(htmlspecialchars($ordem['observacoes']), 0, 50) . '...' : '-'; ?>
                                                                                    </td>
                                                                                    <td class="no-print">
                                                                                        <div class="btn-group btn-group-sm">
                                                                                            <a href="notas.php?ordem=<?php echo $ordem['id']; ?>" 
                                                                                               class="btn btn-sm btn-outline-info" target="_blank">
                                                                                                <i class="bi bi-receipt"></i>
                                                                                            </a>
                                                                                            <button class="btn btn-sm btn-outline-success" 
                                                                                                    onclick="marcarOrdemComoPaga(<?php echo $ordem['id']; ?>)">
                                                                                                <i class="bi bi-check-circle"></i>
                                                                                            </button>
                                                                                        </div>
                                                                                    </td>
                                                                                </tr>
                                                                            <?php endforeach; ?>
                                                                        </tbody>
                                                                        <tfoot>
                                                                            <tr class="table-active">
                                                                                <td colspan="2" class="text-end"><strong>Total:</strong></td>
                                                                                <td class="valor-pendente"><strong><?php echo formatarMoeda($cliente['total_valor_pendente']); ?></strong></td>
                                                                                <td colspan="3"></td>
                                                                            </tr>
                                                                        </tfoot>
                                                                    </table>
                                                                </div>
                                                            <?php else: ?>
                                                                <p class="text-muted">Nenhuma ordem pendente encontrada.</p>
                                                            <?php endif; ?>
                                                            
                                                            <div class="mt-3 no-print">
                                                                <button class="btn btn-sm btn-primary" onclick="abrirModalPagamento(<?php echo $cliente['id']; ?>)">
                                                                    <i class="bi bi-credit-card me-1"></i> Registrar Pagamento
                                                                </button>
                                                                <button class="btn btn-sm btn-warning" onclick="enviarLembreteDetalhado(<?php echo $cliente['id']; ?>)">
                                                                    <i class="bi bi-envelope-paper me-1"></i> Enviar Cobrança Detalhada
                                                                </button>
                                                                <a href="historico_cliente.php?id=<?php echo $cliente['id']; ?>" class="btn btn-sm btn-info">
                                                                    <i class="bi bi-clock-history me-1"></i> Ver Histórico Completo
                                                                </a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                    <tfoot class="table-active">
                                        <tr>
                                            <td colspan="4" class="text-end"><strong>Total Geral:</strong></td>
                                            <td class="valor-pendente"><strong><?php echo formatarMoeda($total_pendente); ?></strong></td>
                                            <td colspan="4"></td>
                                        </tr>
                                    </tfoot>
                                </table>
                            </div>
                            
                            <!-- Paginação -->
                            <div class="d-flex justify-content-between align-items-center mt-3 no-print">
                                <div>
                                    <span class="text-muted">
                                        Mostrando <?php echo count($clientes_pendentes); ?> de <?php echo count($clientes_pendentes); ?> registros
                                    </span>
                                </div>
                                <div>
                                    <button class="btn btn-sm btn-outline-danger" onclick="confirmarExclusaoSelecionados()">
                                        <i class="bi bi-trash"></i> Excluir Selecionados
                                    </button>
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
                
                <!-- Gráfico de Distribuição -->
                <?php if (!empty($clientes_pendentes)): ?>
                    <div class="card mt-4 no-print">
                        <div class="card-header">
                            <h5 class="mb-0"><i class="bi bi-bar-chart me-2"></i>Distribuição de Valores Pendentes</h5>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-8">
                                    <canvas id="graficoPendencias" height="200"></canvas>
                                </div>
                                <div class="col-md-4">
                                    <h6>Resumo por Faixa de Valor:</h6>
                                    <ul class="list-group">
                                        <?php
                                        $faixas = [
                                            '0-50' => ['min' => 0, 'max' => 50, 'count' => 0, 'total' => 0],
                                            '51-200' => ['min' => 51, 'max' => 200, 'count' => 0, 'total' => 0],
                                            '201-500' => ['min' => 201, 'max' => 500, 'count' => 0, 'total' => 0],
                                            '501+' => ['min' => 501, 'max' => 999999, 'count' => 0, 'total' => 0]
                                        ];
                                        
                                        foreach ($clientes_pendentes as $cliente) {
                                            $valor = $cliente['total_valor_pendente'];
                                            foreach ($faixas as $faixa => $dados) {
                                                if ($valor >= $dados['min'] && $valor <= $dados['max']) {
                                                    $faixas[$faixa]['count']++;
                                                    $faixas[$faixa]['total'] += $valor;
                                                    break;
                                                }
                                            }
                                        }
                                        ?>
                                        
                                        <?php foreach ($faixas as $faixa => $dados): ?>
                                            <?php if ($dados['count'] > 0): ?>
                                                <li class="list-group-item d-flex justify-content-between align-items-center">
                                                    R$ <?php echo $faixa; ?>
                                                    <span class="badge bg-primary rounded-pill">
                                                        <?php echo $dados['count']; ?> clientes
                                                        (<?php echo formatarMoeda($dados['total']); ?>)
                                                    </span>
                                                </li>
                                            <?php endif; ?>
                                        <?php endforeach; ?>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <!-- Modal para Enviar Lembretes -->
    <div class="modal fade" id="modalEnviarLembretes" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><i class="bi bi-envelope me-2"></i>Enviar Lembretes de Pagamento</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <form id="formLembretes">
                        <div class="mb-3">
                            <label class="form-label">Selecionar Clientes:</label>
                            <select class="form-select" id="clientesSelect" multiple>
                                <?php foreach ($clientes_pendentes as $cliente): ?>
                                    <option value="<?php echo $cliente['id']; ?>" selected>
                                        <?php echo htmlspecialchars($cliente['nome']); ?> - <?php echo formatarMoeda($cliente['total_valor_pendente']); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                            <div class="form-text">Segure Ctrl para selecionar múltiplos clientes</div>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">Tipo de Mensagem:</label>
                            <select class="form-select" id="tipoMensagem">
                                <option value="lembrete_simples">Lembrete Simples</option>
                                <option value="lembrete_atraso">Lembrete com Atraso</option>
                                <option value="cobrança_urgente">Cobrança Urgente</option>
                                <option value="personalizada">Personalizada</option>
                            </select>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">Mensagem:</label>
                            <textarea class="form-control" id="mensagemLembrete" rows="4" placeholder="Digite a mensagem..."></textarea>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">Enviar por:</label>
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" id="enviarEmail" checked>
                                <label class="form-check-label" for="enviarEmail">E-mail</label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" id="enviarWhatsapp">
                                <label class="form-check-label" for="enviarWhatsapp">WhatsApp</label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" id="enviarSMS">
                                <label class="form-check-label" for="enviarSMS">SMS</label>
                            </div>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                    <button type="button" class="btn btn-primary" onclick="enviarLembretes()">
                        <i class="bi bi-send me-2"></i> Enviar Lembretes
                    </button>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Modal para Registrar Pagamento -->
    <div class="modal fade" id="modalRegistrarPagamento" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><i class="bi bi-credit-card me-2"></i>Registrar Pagamento</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body" id="modalPagamentoBody">
                    <!-- Conteúdo carregado via AJAX -->
                </div>
            </div>
        </div>
    </div>
    
    <!-- Scripts -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.11.5/js/dataTables.bootstrap5.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    
    <script>
        // Inicializar DataTable
        $(document).ready(function() {
            $('#tabelaClientes').DataTable({
                language: {
                    url: '//cdn.datatables.net/plug-ins/1.11.5/i18n/pt-BR.json'
                },
                pageLength: 25,
                ordering: true,
                dom: '<"top"f>rt<"bottom"lip><"clear">',
                columnDefs: [
                    { orderable: false, targets: [0, 8] }
                ]
            });
        });
        
        // Selecionar todos os checkboxes
        document.getElementById('selectAll').addEventListener('change', function() {
            const checkboxes = document.querySelectorAll('.cliente-checkbox');
            checkboxes.forEach(cb => cb.checked = this.checked);
        });
        
        // Funções de ação
        function visualizarCliente(clienteId) {
            window.open(`clientes.php?acao=editar&id=${clienteId}`, '_blank');
        }
        
        function marcarComoPago(clienteId) {
            if (confirm('Deseja marcar TODAS as ordens pendentes deste cliente como PAGAS?')) {
                fetch('ajax/marcar_cliente_pago.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                    },
                    body: `cliente_id=${clienteId}`
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        alert('Pagamentos registrados com sucesso!');
                        location.reload();
                    } else {
                        alert('Erro: ' + data.message);
                    }
                });
            }
        }
        
        function marcarOrdemComoPaga(ordemId) {
            if (confirm('Deseja marcar esta ordem como PAGA?')) {
                fetch('ajax/marcar_ordem_paga.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                    },
                    body: `ordem_id=${ordemId}`
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        alert('Ordem marcada como paga!');
                        location.reload();
                    } else {
                        alert('Erro: ' + data.message);
                    }
                });
            }
        }
        
        function enviarLembrete(clienteId) {
            if (confirm('Enviar lembrete de pagamento para este cliente?')) {
                fetch('ajax/enviar_lembrete.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                    },
                    body: `cliente_id=${clienteId}`
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        alert('Lembrete enviado com sucesso!');
                    } else {
                        alert('Erro: ' + data.message);
                    }
                });
            }
        }
        
        function enviarLembreteDetalhado(clienteId) {
            window.open(`enviar_cobranca.php?cliente_id=${clienteId}`, '_blank');
        }
        
        function abrirModalPagamento(clienteId) {
            fetch(`ajax/carregar_pagamento.php?cliente_id=${clienteId}`)
                .then(response => response.text())
                .then(html => {
                    document.getElementById('modalPagamentoBody').innerHTML = html;
                    new bootstrap.Modal(document.getElementById('modalRegistrarPagamento')).show();
                });
        }
        
        function marcarTodosComoPagos() {
            if (confirm('ATENÇÃO: Deseja marcar TODOS os clientes selecionados como PAGOS?')) {
                const checkboxes = document.querySelectorAll('.cliente-checkbox:checked');
                const ids = Array.from(checkboxes).map(cb => cb.value);
                
                if (ids.length === 0) {
                    alert('Selecione pelo menos um cliente!');
                    return;
                }
                
                fetch('ajax/marcar_varios_pagos.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({ clientes_ids: ids })
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        alert(`${data.count} clientes marcados como pagos!`);
                        location.reload();
                    } else {
                        alert('Erro: ' + data.message);
                    }
                });
            }
        }
        
        function confirmarExclusaoSelecionados() {
            if (confirm('ATENÇÃO: Esta ação não pode ser desfeita. Deseja excluir os clientes selecionados?')) {
                // Implementar exclusão
                alert('Funcionalidade de exclusão em desenvolvimento...');
            }
        }
        
        function exportarParaExcel() {
            // Implementar exportação para Excel
            window.location.href = 'exportar_pendentes.php?tipo=excel';
        }
        
        function enviarLembretes() {
            const clientesSelect = document.getElementById('clientesSelect');
            const selectedIds = Array.from(clientesSelect.selectedOptions).map(opt => opt.value);
            const mensagem = document.getElementById('mensagemLembrete').value;
            const tipo = document.getElementById('tipoMensagem').value;
            
            if (selectedIds.length === 0) {
                alert('Selecione pelo menos um cliente!');
                return;
            }
            
            if (!mensagem.trim()) {
                alert('Digite uma mensagem!');
                return;
            }
            
            fetch('ajax/enviar_lembretes_multi.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    clientes_ids: selectedIds,
                    mensagem: mensagem,
                    tipo: tipo
                })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert(`Lembretes enviados para ${data.count} clientes!`);
                    bootstrap.Modal.getInstance(document.getElementById('modalEnviarLembretes')).hide();
                } else {
                    alert('Erro: ' + data.message);
                }
            });
        }
        
        // Gráfico de distribuição
        <?php if (!empty($clientes_pendentes)): ?>
        document.addEventListener('DOMContentLoaded', function() {
            const ctx = document.getElementById('graficoPendencias').getContext('2d');
            
            // Preparar dados
            const nomes = <?php echo json_encode(array_column($clientes_pendentes, 'nome')); ?>;
            const valores = <?php echo json_encode(array_column($clientes_pendentes, 'total_valor_pendente')); ?>;
            const cores = valores.map(valor => {
                if (valor > 500) return '#ef4444';
                if (valor > 200) return '#f59e0b';
                if (valor > 50) return '#3b82f6';
                return '#10b981';
            });
            
            new Chart(ctx, {
                type: 'bar',
                data: {
                    labels: nomes.map(nome => nome.length > 15 ? nome.substring(0, 15) + '...' : nome),
                    datasets: [{
                        label: 'Valor Pendente (R$)',
                        data: valores,
                        backgroundColor: cores,
                        borderColor: cores.map(cor => cor.replace('0.8', '1')),
                        borderWidth: 1
                    }]
                },
                options: {
                    responsive: true,
                    plugins: {
                        legend: {
                            display: false
                        },
                        tooltip: {
                            callbacks: {
                                label: function(context) {
                                    return 'R$ ' + context.parsed.y.toFixed(2).replace('.', ',');
                                }
                            }
                        }
                    },
                    scales: {
                        y: {
                            beginAtZero: true,
                            ticks: {
                                callback: function(value) {
                                    return 'R$ ' + value.toFixed(2).replace('.', ',');
                                }
                            }
                        },
                        x: {
                            ticks: {
                                maxRotation: 45
                            }
                        }
                    }
                }
            });
        });
        <?php endif; ?>
    </script>
</body>
</html>