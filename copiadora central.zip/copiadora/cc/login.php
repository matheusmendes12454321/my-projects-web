<?php
// login.php - VERSÃO FUNCIONAL
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Redirecionar se já estiver logado
if (isset($_SESSION['usuario_id'])) {
    header('Location: index.php');
    exit();
}

require_once 'config.php';

$erro = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $usuario = sanitizar($_POST['usuario'] ?? '');
    $senha = $_POST['senha'] ?? '';
    
    // Validar campos
    if (empty($usuario) || empty($senha)) {
        $erro = 'Preencha todos os campos!';
    } else {
        $conn = conectarBanco();
        
        // Primeiro, verificar se a tabela usuarios existe
        $tabela_existe = $conn->query("SHOW TABLES LIKE 'usuarios'");
        
        if ($tabela_existe->num_rows == 0) {
            $erro = 'Sistema não configurado. Execute o script de instalação.';
        } else {
            // Buscar usuário no banco de dados
            $stmt = $conn->prepare("SELECT id, nome, usuario, senha, nivel, ativo FROM usuarios WHERE usuario = ?");
            $stmt->bind_param("s", $usuario);
            $stmt->execute();
            $result = $stmt->get_result();
            
            if ($result->num_rows === 1) {
                $usuario_db = $result->fetch_assoc();
                
                // Verificar se usuário está ativo
                if (!$usuario_db['ativo']) {
                    $erro = 'Usuário desativado! Contate o administrador.';
                }
                // Verificar senha
                elseif (verificarSenha($senha, $usuario_db['senha'])) {
                    // Atualizar último login
                    $stmt_update = $conn->prepare("UPDATE usuarios SET ultimo_login = NOW() WHERE id = ?");
                    $stmt_update->bind_param("i", $usuario_db['id']);
                    $stmt_update->execute();
                    
                    // Criar sessão
                    $_SESSION['usuario_id'] = $usuario_db['id'];
                    $_SESSION['usuario_nome'] = $usuario_db['nome'];
                    $_SESSION['usuario_nivel'] = $usuario_db['nivel'];
                    $_SESSION['logged_in'] = true;
                    
                    // Tentar registrar log (não falha se a tabela não existir)
                    @registrarLog($usuario_db['id'], 'login', 'Login realizado com sucesso');
                    
                    // Redirecionar
                    header('Location: index.php');
                    exit();
                } else {
                    $erro = 'Senha incorreta!';
                }
            } else {
                $erro = 'Usuário não encontrado!';
            }
        }
        
        @$stmt->close();
        $conn->close();
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login | Copiadora Central</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .login-box {
            background: white;
            border-radius: 15px;
            padding: 40px;
            box-shadow: 0 20px 40px rgba(0,0,0,0.1);
            max-width: 500px;
            width: 100%;
            margin: 0 auto;
        }
        .logo {
            text-align: center;
            margin-bottom: 30px;
        }
        .logo i {
            font-size: 50px;
            color: #667eea;
            margin-bottom: 15px;
        }
        .logo h1 {
            color: #333;
            font-weight: 700;
        }
        .logo p {
            color: #666;
        }
        .btn-login {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border: none;
            padding: 12px;
            font-weight: 600;
            width: 100%;
        }
        .form-control {
            padding: 12px;
            border-radius: 8px;
        }
        .alert {
            border-radius: 8px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="login-box">
                    <div class="logo">
                        <i class="fas fa-print"></i>
                        <h1>Copiadora Central</h1>
                        <p>Sistema de Gestão</p>
                    </div>
                    
                    <?php if ($erro): ?>
                        <div class="alert alert-danger">
                            <i class="fas fa-exclamation-triangle me-2"></i>
                            <?php echo htmlspecialchars($erro); ?>
                        </div>
                    <?php endif; ?>
                    
                    <form method="POST">
                        <div class="mb-3">
                            <label class="form-label">Usuário</label>
                            <input type="text" class="form-control" name="usuario" required 
                                   placeholder="Digite seu usuário" value="admin">
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">Senha</label>
                            <input type="password" class="form-control" name="senha" required 
                                   placeholder="Digite sua senha" value="admin123">
                            <div class="form-text">
                                <a href="javascript:void(0)" onclick="alert('Contate o administrador')">
                                    <i class="fas fa-key me-1"></i>Esqueceu a senha?
                                </a>
                            </div>
                        </div>
                        
                        <button type="submit" class="btn btn-login text-white">
                            <i class="fas fa-sign-in-alt me-2"></i>Entrar
                        </button>
                    </form>
                    
                    <div class="mt-4 text-center">
                        <div class="card card-body bg-light">
                            <h6><i class="fas fa-info-circle me-2"></i>Credenciais de Teste</h6>
                            <p class="mb-1"><strong>Admin:</strong> admin / password</p>
                            <p class="mb-0"><strong>Operador:</strong> operador / password</p>
                        </div>
                    </div>
                    
                    <div class="mt-4 text-center">
                        <p class="text-muted small">
                            <i class="fas fa-copyright"></i> <?php echo date('Y'); ?> Copiadora Central
                            <span class="mx-2">•</span>
                            <i class="fas fa-wrench"></i> 
                            <a href="setup_sistema.php" class="text-decoration-none">Configurar Sistema</a>
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>