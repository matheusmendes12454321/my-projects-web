<?php
// clientes.php
require_once 'config.php';
verificarLogin();

$conn = conectarBanco();
$acao = $_GET['acao'] ?? 'listar';

// Verificar a estrutura da tabela
$result = $conn->query("SHOW COLUMNS FROM clientes");
$colunas_existentes = [];
while ($row = $result->fetch_assoc()) {
    $colunas_existentes[] = $row['Field'];
}

// Verificar quais colunas existem
$tem_nome = in_array('nome', $colunas_existentes);
$tem_cpf_cnpj = in_array('cpf_cnpj', $colunas_existentes);
$tem_telefone = in_array('telefone', $colunas_existentes);
$tem_email = in_array('email', $colunas_existentes);
$tem_endereco = in_array('endereco', $colunas_existentes);
$tem_tipo = in_array('tipo', $colunas_existentes);
$tem_data_cadastro = in_array('data_cadastro', $colunas_existentes);

// Processar ações
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['salvar_cliente'])) {
        $nome = $_POST['nome'] ?? '';
        $cpf_cnpj = $_POST['cpf_cnpj'] ?? '';
        $telefone = $_POST['telefone'] ?? '';
        $email = $_POST['email'] ?? '';
        $endereco = $_POST['endereco'] ?? '';
        $tipo = $_POST['tipo'] ?? 'normal';
        
        if (isset($_POST['id']) && !empty($_POST['id'])) {
            // Atualizar
            $id = $_POST['id'];
            
            // Construir query dinamicamente baseada nas colunas existentes
            $campos = [];
            $tipos = "";
            $valores = [];
            
            if ($tem_nome) { $campos[] = "nome=?"; $tipos .= "s"; $valores[] = &$nome; }
            if ($tem_cpf_cnpj) { $campos[] = "cpf_cnpj=?"; $tipos .= "s"; $valores[] = &$cpf_cnpj; }
            if ($tem_telefone) { $campos[] = "telefone=?"; $tipos .= "s"; $valores[] = &$telefone; }
            if ($tem_email) { $campos[] = "email=?"; $tipos .= "s"; $valores[] = &$email; }
            if ($tem_endereco) { $campos[] = "endereco=?"; $tipos .= "s"; $valores[] = &$endereco; }
            if ($tem_tipo) { $campos[] = "tipo=?"; $tipos .= "s"; $valores[] = &$tipo; }
            
            $tipos .= "i"; // Para o ID
            $valores[] = &$id;
            
            $sql = "UPDATE clientes SET " . implode(", ", $campos) . " WHERE id=?";
            $stmt = $conn->prepare($sql);
            
            if ($stmt) {
                $stmt->bind_param($tipos, ...$valores);
                $stmt->execute();
            }
            
        } else {
            // Inserir
            $campos = [];
            $placeholders = [];
            $tipos = "";
            $valores = [];
            
            if ($tem_nome) { $campos[] = "nome"; $placeholders[] = "?"; $tipos .= "s"; $valores[] = &$nome; }
            if ($tem_cpf_cnpj) { $campos[] = "cpf_cnpj"; $placeholders[] = "?"; $tipos .= "s"; $valores[] = &$cpf_cnpj; }
            if ($tem_telefone) { $campos[] = "telefone"; $placeholders[] = "?"; $tipos .= "s"; $valores[] = &$telefone; }
            if ($tem_email) { $campos[] = "email"; $placeholders[] = "?"; $tipos .= "s"; $valores[] = &$email; }
            if ($tem_endereco) { $campos[] = "endereco"; $placeholders[] = "?"; $tipos .= "s"; $valores[] = &$endereco; }
            if ($tem_tipo) { $campos[] = "tipo"; $placeholders[] = "?"; $tipos .= "s"; $valores[] = &$tipo; }
            
            $sql = "INSERT INTO clientes (" . implode(", ", $campos) . ") VALUES (" . implode(", ", $placeholders) . ")";
            $stmt = $conn->prepare($sql);
            
            if ($stmt) {
                $stmt->bind_param($tipos, ...$valores);
                $stmt->execute();
            }
        }
        
        if ($stmt && $stmt->affected_rows > 0) {
            header('Location: clientes.php?msg=sucesso');
            exit();
        } else {
            header('Location: clientes.php?msg=erro');
            exit();
        }
        
    } elseif (isset($_POST['excluir_cliente'])) {
        $id = $_POST['id'];
        $stmt = $conn->prepare("DELETE FROM clientes WHERE id=?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        header('Location: clientes.php?msg=excluido');
        exit();
    }
}

// Listar clientes
$clientes = [];
if ($acao === 'listar') {
    // Construir SELECT dinamicamente
    $campos_select = [];
    foreach ($colunas_existentes as $coluna) {
        $campos_select[] = $coluna;
    }
    $sql = "SELECT " . implode(", ", $campos_select) . " FROM clientes ORDER BY nome";
    $result = $conn->query($sql);
    
    while ($row = $result->fetch_assoc()) {
        $clientes[] = $row;
    }
}

// Buscar cliente para edição
$cliente_edit = null;
if ($acao === 'editar' && isset($_GET['id'])) {
    $id = $_GET['id'];
    $result = $conn->query("SELECT * FROM clientes WHERE id = $id");
    $cliente_edit = $result->fetch_assoc();
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Clientes - Copiadora Central</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css">
</head>
<body>
    <?php include 'navbar.php'; ?>
    
    <div class="container-fluid mt-4">
        <div class="row">
            <?php include 'sidebar.php'; ?>
            
            <div class="col-md-10">
                <h2>Clientes</h2>
                
                <!-- Debug: Mostrar colunas existentes -->
                <!-- 
                <div class="alert alert-info">
                    Colunas existentes na tabela: <?php echo implode(', ', $colunas_existentes); ?>
                </div>
                -->
                
                <?php if ($acao === 'listar' || $acao === 'editar'): ?>
                    <div class="mb-3">
                        <a href="clientes.php?acao=novo" class="btn btn-primary">
                            <i class="bi bi-plus-circle me-2"></i> Novo Cliente
                        </a>
                        <button class="btn btn-secondary" onclick="window.print()">
                            <i class="bi bi-printer me-2"></i> Imprimir
                        </button>
                    </div>
                    
                    <?php if (isset($_GET['msg'])): ?>
                        <div class="alert alert-<?php echo $_GET['msg'] === 'erro' ? 'danger' : 'success'; ?>">
                            <?php 
                                switch($_GET['msg']) {
                                    case 'sucesso': echo 'Cliente salvo com sucesso!'; break;
                                    case 'excluido': echo 'Cliente excluído com sucesso!'; break;
                                    case 'erro': echo 'Erro ao salvar cliente!'; break;
                                }
                            ?>
                        </div>
                    <?php endif; ?>
                    
                    <?php if (!empty($clientes)): ?>
                    <div class="card">
                        <div class="card-header">
                            <h5>Lista de Clientes (<?php echo count($clientes); ?>)</h5>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-striped table-hover">
                                    <thead>
                                        <tr>
                                            <th>ID</th>
                                            <?php if ($tem_nome): ?><th>Nome</th><?php endif; ?>
                                            <?php if ($tem_cpf_cnpj): ?><th>CPF/CNPJ</th><?php endif; ?>
                                            <?php if ($tem_telefone): ?><th>Telefone</th><?php endif; ?>
                                            <?php if ($tem_email): ?><th>E-mail</th><?php endif; ?>
                                            <?php if ($tem_tipo): ?><th>Tipo</th><?php endif; ?>
                                            <?php if ($tem_data_cadastro): ?><th>Data Cadastro</th><?php endif; ?>
                                            <th>Ações</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($clientes as $cliente): ?>
                                            <tr>
                                                <td><?php echo $cliente['id']; ?></td>
                                                <?php if ($tem_nome): ?><td><?php echo htmlspecialchars($cliente['nome'] ?? ''); ?></td><?php endif; ?>
                                                <?php if ($tem_cpf_cnpj): ?><td><?php echo htmlspecialchars($cliente['cpf_cnpj'] ?? ''); ?></td><?php endif; ?>
                                                <?php if ($tem_telefone): ?><td><?php echo htmlspecialchars($cliente['telefone'] ?? ''); ?></td><?php endif; ?>
                                                <?php if ($tem_email): ?><td><?php echo htmlspecialchars($cliente['email'] ?? ''); ?></td><?php endif; ?>
                                                <?php if ($tem_tipo): ?>
                                                <td>
                                                    <span class="badge bg-<?php echo ($cliente['tipo'] ?? 'normal') === 'anonimo' ? 'warning' : 'info'; ?>">
                                                        <?php echo ($cliente['tipo'] ?? 'normal') === 'anonimo' ? 'Anônimo' : 'Normal'; ?>
                                                    </span>
                                                </td>
                                                <?php endif; ?>
                                                <?php if ($tem_data_cadastro): ?>
                                                <td>
                                                    <?php 
                                                    if (isset($cliente['data_cadastro']) && function_exists('formatarData')) {
                                                        echo formatarData($cliente['data_cadastro']);
                                                    } elseif (isset($cliente['data_cadastro'])) {
                                                        echo date('d/m/Y H:i', strtotime($cliente['data_cadastro']));
                                                    }
                                                    ?>
                                                </td>
                                                <?php endif; ?>
                                                <td>
                                                    <a href="clientes.php?acao=editar&id=<?php echo $cliente['id']; ?>" class="btn btn-sm btn-warning">
                                                        <i class="bi bi-pencil"></i>
                                                    </a>
                                                    <button class="btn btn-sm btn-danger" data-bs-toggle="modal" data-bs-target="#modalExcluir<?php echo $cliente['id']; ?>">
                                                        <i class="bi bi-trash"></i>
                                                    </button>
                                                    
                                                    <!-- Modal de Exclusão -->
                                                    <div class="modal fade" id="modalExcluir<?php echo $cliente['id']; ?>" tabindex="-1">
                                                        <div class="modal-dialog">
                                                            <div class="modal-content">
                                                                <div class="modal-header">
                                                                    <h5 class="modal-title">Confirmar Exclusão</h5>
                                                                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                                                </div>
                                                                <div class="modal-body">
                                                                    Tem certeza que deseja excluir o cliente <?php echo htmlspecialchars($cliente['nome'] ?? 'ID ' . $cliente['id']); ?>?
                                                                </div>
                                                                <div class="modal-footer">
                                                                    <form method="POST" style="display: inline;">
                                                                        <input type="hidden" name="id" value="<?php echo $cliente['id']; ?>">
                                                                        <button type="submit" name="excluir_cliente" class="btn btn-danger">Excluir</button>
                                                                    </form>
                                                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    <?php else: ?>
                    <div class="alert alert-info">
                        Nenhum cliente cadastrado ainda.
                    </div>
                    <?php endif; ?>
                <?php endif; ?>
                
                <?php if ($acao === 'novo' || $acao === 'editar'): ?>
                    <div class="card">
                        <div class="card-header">
                            <h5><?php echo $acao === 'novo' ? 'Novo Cliente' : 'Editar Cliente'; ?></h5>
                        </div>
                        <div class="card-body">
                            <form method="POST">
                                <input type="hidden" name="id" value="<?php echo $cliente_edit['id'] ?? ''; ?>">
                                
                                <div class="row mb-3">
                                    <?php if ($tem_nome): ?>
                                    <div class="col-md-6">
                                        <label for="nome" class="form-label">Nome <?php echo $tem_nome && $acao === 'novo' ? '*' : ''; ?></label>
                                        <input type="text" class="form-control" id="nome" name="nome" 
                                               value="<?php echo $cliente_edit['nome'] ?? ''; ?>" <?php echo $tem_nome && $acao === 'novo' ? 'required' : ''; ?>>
                                    </div>
                                    <?php endif; ?>
                                    
                                    <?php if ($tem_cpf_cnpj): ?>
                                    <div class="col-md-6">
                                        <label for="cpf_cnpj" class="form-label">CPF/CNPJ</label>
                                        <input type="text" class="form-control" id="cpf_cnpj" name="cpf_cnpj"
                                               value="<?php echo $cliente_edit['cpf_cnpj'] ?? ''; ?>">
                                    </div>
                                    <?php endif; ?>
                                </div>
                                
                                <div class="row mb-3">
                                    <?php if ($tem_telefone): ?>
                                    <div class="col-md-6">
                                        <label for="telefone" class="form-label">Telefone</label>
                                        <input type="text" class="form-control" id="telefone" name="telefone"
                                               value="<?php echo $cliente_edit['telefone'] ?? ''; ?>">
                                    </div>
                                    <?php endif; ?>
                                    
                                    <?php if ($tem_email): ?>
                                    <div class="col-md-6">
                                        <label for="email" class="form-label">E-mail</label>
                                        <input type="email" class="form-control" id="email" name="email"
                                               value="<?php echo $cliente_edit['email'] ?? ''; ?>">
                                    </div>
                                    <?php endif; ?>
                                </div>
                                
                                <?php if ($tem_endereco): ?>
                                <div class="mb-3">
                                    <label for="endereco" class="form-label">Endereço</label>
                                    <textarea class="form-control" id="endereco" name="endereco" rows="2"><?php echo $cliente_edit['endereco'] ?? ''; ?></textarea>
                                </div>
                                <?php endif; ?>
                                
                                <?php if ($tem_tipo): ?>
                                <div class="mb-3">
                                    <label for="tipo" class="form-label">Tipo de Cliente</label>
                                    <select class="form-select" id="tipo" name="tipo">
                                        <option value="normal" <?php echo ($cliente_edit['tipo'] ?? 'normal') === 'normal' ? 'selected' : ''; ?>>Normal</option>
                                        <option value="anonimo" <?php echo ($cliente_edit['tipo'] ?? 'normal') === 'anonimo' ? 'selected' : ''; ?>>Anônimo</option>
                                    </select>
                                </div>
                                <?php endif; ?>
                                
                                <div class="d-flex gap-2">
                                    <button type="submit" name="salvar_cliente" class="btn btn-primary">
                                        <i class="bi bi-save me-2"></i> Salvar
                                    </button>
                                    <a href="clientes.php" class="btn btn-secondary">Cancelar</a>
                                </div>
                            </form>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>