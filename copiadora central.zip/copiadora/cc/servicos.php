<?php
// servicos.php
require_once 'config.php';
verificarLogin();

$conn = conectarBanco();
$acao = $_GET['acao'] ?? 'listar';

// Processar ações
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['salvar_servico'])) {
        $nome = $_POST['nome'];
        $descricao = $_POST['descricao'];
        $valor = str_replace(',', '.', str_replace('.', '', $_POST['valor']));
        $tempo_estimado = $_POST['tempo_estimado'];
        
        if (isset($_POST['id']) && !empty($_POST['id'])) {
            // Atualizar
            $id = $_POST['id'];
            $stmt = $conn->prepare("UPDATE servicos SET nome=?, descricao=?, valor=?, tempo_estimado=? WHERE id=?");
            $stmt->bind_param("ssdsi", $nome, $descricao, $valor, $tempo_estimado, $id);
        } else {
            // Inserir
            $stmt = $conn->prepare("INSERT INTO servicos (nome, descricao, valor, tempo_estimado) VALUES (?, ?, ?, ?)");
            $stmt->bind_param("ssds", $nome, $descricao, $valor, $tempo_estimado);
        }
        
        if ($stmt->execute()) {
            header('Location: servicos.php?msg=sucesso');
            exit();
        }
    } elseif (isset($_POST['toggle_status'])) {
        $id = $_POST['id'];
        $ativo = $_POST['ativo'];
        $stmt = $conn->prepare("UPDATE servicos SET ativo=? WHERE id=?");
        $stmt->bind_param("ii", $ativo, $id);
        $stmt->execute();
        header('Location: servicos.php?msg=status');
        exit();
    }
}

// Listar serviços
$servicos = [];
if ($acao === 'listar') {
    $result = $conn->query("SELECT * FROM servicos ORDER BY nome");
    while ($row = $result->fetch_assoc()) {
        $servicos[] = $row;
    }
}

// Buscar serviço para edição
$servico_edit = null;
if ($acao === 'editar' && isset($_GET['id'])) {
    $id = $_GET['id'];
    $result = $conn->query("SELECT * FROM servicos WHERE id = $id");
    $servico_edit = $result->fetch_assoc();
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Serviços - Copiadora Central</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css">
</head>
<body>
    <?php include 'navbar.php'; ?>
    
    <div class="container-fluid mt-4">
        <div class="row">
            <?php include 'sidebar.php'; ?>
            
            <div class="col-md-10">
                <h2>Serviços</h2>
                
                <?php if ($acao === 'listar' || $acao === 'editar'): ?>
                    <div class="mb-3">
                        <a href="servicos.php?acao=novo" class="btn btn-primary">
                            <i class="bi bi-plus-circle me-2"></i> Novo Serviço
                        </a>
                    </div>
                    
                    <?php if (isset($_GET['msg'])): ?>
                        <div class="alert alert-success">
                            <?php 
                                switch($_GET['msg']) {
                                    case 'sucesso': echo 'Serviço salvo com sucesso!'; break;
                                    case 'status': echo 'Status alterado com sucesso!'; break;
                                }
                            ?>
                        </div>
                    <?php endif; ?>
                    
                    <div class="card">
                        <div class="card-header">
                            <h5>Lista de Serviços</h5>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-striped table-hover">
                                    <thead>
                                        <tr>
                                            <th>ID</th>
                                            <th>Nome</th>
                                            <th>Descrição</th>
                                            <th>Valor</th>
                                            <th>Tempo Estimado</th>
                                            <th>Status</th>
                                            <th>Ações</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($servicos as $servico): ?>
                                            <tr>
                                                <td><?php echo $servico['id']; ?></td>
                                                <td><?php echo htmlspecialchars($servico['nome']); ?></td>
                                                <td><?php echo htmlspecialchars($servico['descricao']); ?></td>
                                                <td><?php echo formatarMoeda($servico['valor']); ?></td>
                                                <td><?php echo htmlspecialchars($servico['tempo_estimado']); ?></td>
                                                <td>
                                                    <form method="POST" style="display: inline;">
                                                        <input type="hidden" name="id" value="<?php echo $servico['id']; ?>">
                                                        <input type="hidden" name="ativo" value="<?php echo $servico['ativo'] ? 0 : 1; ?>">
                                                        <button type="submit" name="toggle_status" class="btn btn-sm btn-<?php echo $servico['ativo'] ? 'success' : 'secondary'; ?>">
                                                            <?php echo $servico['ativo'] ? 'Ativo' : 'Inativo'; ?>
                                                        </button>
                                                    </form>
                                                </td>
                                                <td>
                                                    <a href="servicos.php?acao=editar&id=<?php echo $servico['id']; ?>" class="btn btn-sm btn-warning">
                                                        <i class="bi bi-pencil"></i>
                                                    </a>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
                
                <?php if ($acao === 'novo' || $acao === 'editar'): ?>
                    <div class="card">
                        <div class="card-header">
                            <h5><?php echo $acao === 'novo' ? 'Novo Serviço' : 'Editar Serviço'; ?></h5>
                        </div>
                        <div class="card-body">
                            <form method="POST">
                                <input type="hidden" name="id" value="<?php echo $servico_edit['id'] ?? ''; ?>">
                                
                                <div class="mb-3">
                                    <label for="nome" class="form-label">Nome do Serviço *</label>
                                    <input type="text" class="form-control" id="nome" name="nome" 
                                           value="<?php echo $servico_edit['nome'] ?? ''; ?>" required>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="descricao" class="form-label">Descrição</label>
                                    <textarea class="form-control" id="descricao" name="descricao" rows="3"><?php echo $servico_edit['descricao'] ?? ''; ?></textarea>
                                </div>
                                
                                <div class="row mb-3">
                                    <div class="col-md-6">
                                        <label for="valor" class="form-label">Valor (R$) *</label>
                                        <input type="text" class="form-control" id="valor" name="valor" 
                                               value="<?php echo isset($servico_edit['valor']) ? number_format($servico_edit['valor'], 2, ',', '.') : ''; ?>" required>
                                    </div>
                                    <div class="col-md-6">
                                        <label for="tempo_estimado" class="form-label">Tempo Estimado</label>
                                        <input type="text" class="form-control" id="tempo_estimado" name="tempo_estimado"
                                               value="<?php echo $servico_edit['tempo_estimado'] ?? ''; ?>" 
                                               placeholder="Ex: 30 minutos, 1 hora, etc.">
                                    </div>
                                </div>
                                
                                <div class="d-flex gap-2">
                                    <button type="submit" name="salvar_servico" class="btn btn-primary">
                                        <i class="bi bi-save me-2"></i> Salvar
                                    </button>
                                    <a href="servicos.php" class="btn btn-secondary">Cancelar</a>
                                </div>
                            </form>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Máscara para valor monetário
        document.getElementById('valor')?.addEventListener('input', function(e) {
            let value = e.target.value.replace(/\D/g, '');
            value = (value / 100).toFixed(2) + '';
            value = value.replace('.', ',');
            value = value.replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1.');
            e.target.value = value;
        });
    </script>
</body>
</html>