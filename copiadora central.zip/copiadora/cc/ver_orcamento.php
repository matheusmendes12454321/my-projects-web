<?php
// ver_orcamento.php
require_once 'config.php';
verificarLogin();

$conn = conectarBanco();
$orcamento_id = $_GET['id'] ?? 0;

// Buscar dados do orçamento
$query = "
    SELECT o.*, 
           c.nome as cliente_nome,
           c.cpf_cnpj as cliente_cpf_cnpj,
           c.telefone as cliente_telefone,
           c.email as cliente_email,
           c.endereco as cliente_endereco,
           c.tipo as cliente_tipo
    FROM orcamentos o
    LEFT JOIN clientes c ON o.cliente_id = c.id
    WHERE o.id = ?
";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $orcamento_id);
$stmt->execute();
$orcamento = $stmt->get_result()->fetch_assoc();

if (!$orcamento) {
    die("Orçamento não encontrado!");
}

// Buscar itens do orçamento
$itens = $conn->query("
    SELECT oi.*, s.nome as servico_nome
    FROM orcamento_itens oi
    JOIN servicos s ON oi.servico_id = s.id
    WHERE oi.orcamento_id = $orcamento_id
");
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Orçamento - Copiadora Central</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        @media print {
            .no-print {
                display: none !important;
            }
            body {
                font-size: 12px;
            }
            .container {
                width: 100%;
                max-width: none;
            }
        }
        .orcamento-container {
            border: 2px solid #000;
            padding: 20px;
            margin: 20px auto;
            max-width: 800px;
        }
        .empresa-header {
            text-align: center;
            border-bottom: 2px solid #000;
            padding-bottom: 15px;
            margin-bottom: 20px;
        }
        .empresa-header h2 {
            margin: 0;
            font-weight: bold;
        }
        .empresa-header p {
            margin: 5px 0;
        }
        .detalhes-cliente {
            margin-bottom: 20px;
        }
        .detalhes-orcamento {
            margin-bottom: 20px;
        }
        .table-orcamento {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        .table-orcamento th,
        .table-orcamento td {
            border: 1px solid #000;
            padding: 8px;
            text-align: left;
        }
        .table-orcamento th {
            background-color: #f8f9fa;
        }
        .total-box {
            text-align: right;
            margin-top: 20px;
        }
        .assinatura {
            margin-top: 50px;
            border-top: 1px solid #000;
            padding-top: 10px;
            text-align: center;
        }
        .termos-condicoes {
            margin-top: 30px;
            font-size: 0.9em;
            border-top: 1px dashed #ccc;
            padding-top: 15px;
        }
        .status-badge {
            font-size: 1em;
            padding: 8px 15px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="no-print text-center mb-3">
            <button onclick="window.print()" class="btn btn-primary me-2">
                <i class="bi bi-printer"></i> Imprimir Orçamento
            </button>
            <a href="orcamentos.php" class="btn btn-secondary me-2">
                <i class="bi bi-arrow-left"></i> Voltar
            </a>
            <?php if ($orcamento['status'] == 'aprovado'): ?>
                <form method="POST" action="orcamentos.php" style="display: inline;">
                    <input type="hidden" name="orcamento_id" value="<?php echo $orcamento_id; ?>">
                    <button type="submit" name="converter_para_ordem" class="btn btn-success">
                        <i class="bi bi-arrow-right-circle"></i> Converter em Ordem
                    </button>
                </form>
            <?php endif; ?>
        </div>
        
        <div class="orcamento-container">
            <!-- Cabeçalho da Empresa -->
            <div class="empresa-header">
                <h2><?php echo EMPRESA_NOME; ?></h2>
                <p>CNPJ: <?php echo EMPRESA_CNPJ; ?></p>
                <p><?php echo EMPRESA_ENDERECO; ?> - <?php echo EMPRESA_CIDADE; ?></p>
                <p>Telefone: <?php echo EMPRESA_TELEFONE; ?> | E-mail: <?php echo EMPRESA_EMAIL; ?></p>
            </div>
            
            <!-- Título -->
            <div class="text-center mb-4">
                <h1>ORÇAMENTO</h1>
                <p class="mb-0">Documento válido para proposta comercial</p>
            </div>
            
            <!-- Informações do Orçamento -->
            <div class="detalhes-orcamento row">
                <div class="col-md-6">
                    <p><strong>ORÇAMENTO #<?php echo str_pad($orcamento['id'], 6, '0', STR_PAD_LEFT); ?></strong></p>
                    <p><strong>Data de Emissão:</strong> <?php echo formatarData($orcamento['data_orcamento'], 'd/m/Y H:i'); ?></p>
                    <p><strong>Válido Até:</strong> <?php echo formatarData($orcamento['valido_ate']); ?></p>
                </div>
                <div class="col-md-6">
                    <p><strong>Status:</strong> 
                        <span class="badge status-badge bg-<?php 
                            switch($orcamento['status']) {
                                case 'pendente': echo 'warning'; break;
                                case 'aprovado': echo 'success'; break;
                                case 'rejeitado': echo 'danger'; break;
                                case 'convertido': echo 'info'; break;
                            }
                        ?>">
                            <?php echo strtoupper($orcamento['status']); ?>
                        </span>
                    </p>
                </div>
            </div>
            
            <!-- Informações do Cliente -->
            <div class="detalhes-cliente">
                <h5>Dados do Cliente</h5>
                <div class="row">
                    <div class="col-md-6">
                        <p><strong>Nome:</strong> 
                            <?php 
                            if ($orcamento['cliente_tipo'] === 'anonimo') {
                                echo 'CLIENTE ANÔNIMO';
                            } else {
                                echo htmlspecialchars($orcamento['cliente_nome'] ?? 'N/A');
                            }
                            ?>
                        </p>
                        <?php if ($orcamento['cliente_tipo'] !== 'anonimo' && !empty($orcamento['cliente_cpf_cnpj'])): ?>
                            <p><strong>CPF/CNPJ:</strong> <?php echo htmlspecialchars($orcamento['cliente_cpf_cnpj']); ?></p>
                        <?php endif; ?>
                    </div>
                    <div class="col-md-6">
                        <?php if ($orcamento['cliente_tipo'] !== 'anonimo'): ?>
                            <?php if (!empty($orcamento['cliente_telefone'])): ?>
                                <p><strong>Telefone:</strong> <?php echo htmlspecialchars($orcamento['cliente_telefone']); ?></p>
                            <?php endif; ?>
                            <?php if (!empty($orcamento['cliente_endereco'])): ?>
                                <p><strong>Endereço:</strong> <?php echo htmlspecialchars($orcamento['cliente_endereco']); ?></p>
                            <?php endif; ?>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            
            <!-- Itens do Orçamento -->
            <table class="table-orcamento">
                <thead>
                    <tr>
                        <th>Item</th>
                        <th>Descrição do Serviço</th>
                        <th>Quantidade</th>
                        <th>Valor Unitário</th>
                        <th>Subtotal</th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                    $contador = 1;
                    while ($item = $itens->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo $contador++; ?></td>
                            <td><?php echo htmlspecialchars($item['servico_nome']); ?></td>
                            <td><?php echo $item['quantidade']; ?></td>
                            <td><?php echo formatarMoeda($item['valor_unitario']); ?></td>
                            <td><?php echo formatarMoeda($item['subtotal']); ?></td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
            
            <!-- Totais -->
            <div class="total-box">
                <h4><strong>VALOR TOTAL DO ORÇAMENTO:</strong> <?php echo formatarMoeda($orcamento['valor_total']); ?></h4>
            </div>
            
            <!-- Observações -->
            <?php if (!empty($orcamento['observacoes'])): ?>
                <div class="observacoes">
                    <h5>Observações:</h5>
                    <p><?php echo nl2br(htmlspecialchars($orcamento['observacoes'])); ?></p>
                </div>
            <?php endif; ?>
            
            <!-- Termos e Condições -->
            <div class="termos-condicoes">
                <h5>Termos e Condições:</h5>
                <ol>
                    <li>Este orçamento é válido até a data indicada acima</li>
                    <li>Preços sujeitos a alteração sem aviso prévio</li>
                    <li>Pagamento à vista ou conforme acordado</li>
                    <li>Prazo de entrega conforme disponibilidade</li>
                    <li>Para aprovação, assinar no espaço reservado abaixo</li>
                </ol>
            </div>
            
            <!-- Assinaturas -->
            <div class="row assinatura">
                <div class="col-md-6">
                    <p>_________________________________</p>
                    <p><strong>Copiadora Central</strong></p>
                    <p>Responsável pela proposta</p>
                </div>
                <div class="col-md-6">
                    <p>_________________________________</p>
                    <p><strong>Cliente</strong></p>
                    <p>Aceito os termos e condições acima</p>
                </div>
            </div>
            
            <!-- Rodapé -->
            <div class="text-center mt-4">
                <p><em>Agradecemos pela preferência! Aguardamos seu contato para prosseguirmos com o serviço.</em></p>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>