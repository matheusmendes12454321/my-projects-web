<?php
// criar_usuarios_iniciais.php
require_once 'config.php';

$conn = conectarBanco();

// Verificar se já existem usuários
$result = $conn->query("SELECT COUNT(*) as total FROM usuarios");
$row = $result->fetch_assoc();

if ($row['total'] == 0) {
    // Criar usuário admin
    $senha_admin = password_hash('admin123', PASSWORD_DEFAULT);
    $stmt = $conn->prepare("INSERT INTO usuarios (nome, usuario, senha, nivel) VALUES (?, ?, ?, ?)");
    $nome = "Administrador";
    $usuario = "admin";
    $nivel = "admin";
    $stmt->bind_param("ssss", $nome, $usuario, $senha_admin, $nivel);
    $stmt->execute();
    
    // Criar usuário operador
    $senha_operador = password_hash('operador123', PASSWORD_DEFAULT);
    $nome = "Operador";
    $usuario = "operador";
    $nivel = "operador";
    $stmt->bind_param("ssss", $nome, $usuario, $senha_operador, $nivel);
    $stmt->execute();
    
    echo "<h3>Usuários criados com sucesso!</h3>";
    echo "<p><strong>Administrador:</strong> admin / admin123</p>";
    echo "<p><strong>Operador:</strong> operador / operador123</p>";
    echo '<p><a href="login.php">Ir para login</a></p>';
} else {
    echo "<p>Usuários já existem no sistema.</p>";
    echo '<p><a href="login.php">Ir para login</a></p>';
}

$conn->close();
?>