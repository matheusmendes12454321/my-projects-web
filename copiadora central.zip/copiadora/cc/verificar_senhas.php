<?php
// verificar_senhas.php
require_once 'config.php';

$conn = conectarBanco();

echo "<h2>Verificando Usuários no Banco de Dados</h2>";

// Listar todos os usuários
$result = $conn->query("SELECT id, nome, usuario, senha, nivel FROM usuarios");

if ($result->num_rows > 0) {
    echo "<table border='1' cellpadding='10'>";
    echo "<tr><th>ID</th><th>Nome</th><th>Usuário</th><th>Senha (Hash)</th><th>Nível</th><th>Testar Senha</th></tr>";
    
    while ($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>{$row['id']}</td>";
        echo "<td>{$row['nome']}</td>";
        echo "<td>{$row['usuario']}</td>";
        echo "<td style='font-size: 10px;'>{$row['senha']}</td>";
        echo "<td>{$row['nivel']}</td>";
        
        // Testar senhas comuns
        $senhas_testar = ['admin123', 'copiadora123', 'operador123', '123456', 'password'];
        $encontrada = false;
        
        foreach ($senhas_testar as $senha_teste) {
            if (password_verify($senha_teste, $row['senha'])) {
                echo "<td style='background-color: lightgreen;'>✓ {$senha_teste}</td>";
                $encontrada = true;
                break;
            }
        }
        
        if (!$encontrada) {
            echo "<td style='background-color: lightcoral;'>✗ Não reconhecida</td>";
        }
        
        echo "</tr>";
    }
    
    echo "</table>";
} else {
    echo "<p style='color: red;'>NENHUM USUÁRIO ENCONTRADO NO BANCO!</p>";
}

$conn->close();
?>