<?php
require_once '../config.php';
verificarLogin();

$conn = conectarBanco();
$cliente_id = $_POST['cliente_id'];

// Buscar dados do cliente
$stmt = $conn->prepare("SELECT nome, email, telefone FROM clientes WHERE id = ?");
$stmt->bind_param("i", $cliente_id);
$stmt->execute();
$result = $stmt->get_result();
$cliente = $result->fetch_assoc();

// Buscar ordens pendentes
$ordens = $conn->query("
    SELECT id, valor_final, data_ordem 
    FROM ordens_servico 
    WHERE cliente_id = $cliente_id 
    AND status_pagamento = 'pendente'
");

$total_pendente = 0;
$ordens_lista = [];
while ($ordem = $ordens->fetch_assoc()) {
    $total_pendente += $ordem['valor_final'];
    $ordens_lista[] = $ordem;
}

// Aqui você implementaria o envio real de e-mail
// Por enquanto, apenas registramos no log

registrarLog($_SESSION['usuario_id'], 'envio_lembrete', "Enviou lembrete para cliente #{$cliente_id}");

echo json_encode([
    'success' => true, 
    'message' => 'Lembrete preparado para envio',
    'cliente' => $cliente,
    'total_pendente' => $total_pendente,
    'quantidade_ordens' => count($ordens_lista)
]);

$stmt->close();
$conn->close();
?>