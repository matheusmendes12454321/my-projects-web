<?php
// exportar_pendentes.php
require_once 'config.php';
verificarLogin();

$conn = conectarBanco();
$tipo = $_GET['tipo'] ?? 'excel';

// Buscar dados (mesma query da página principal)
$query = "
    SELECT 
        c.nome,
        c.cpf_cnpj,
        c.telefone,
        c.email,
        COUNT(os.id) as total_ordens_pendentes,
        SUM(os.valor_final) as total_valor_pendente,
        MAX(os.data_ordem) as ultima_ordem,
        DATEDIFF(CURDATE(), MAX(os.data_ordem)) as dias_atraso
    FROM clientes c
    INNER JOIN ordens_servico os ON c.id = os.cliente_id
    WHERE os.status_pagamento = 'pendente'
    AND os.status NOT IN ('cancelado')
    AND c.tipo = 'normal'
    GROUP BY c.id
    HAVING total_valor_pendente > 0
    ORDER BY total_valor_pendente DESC
";

$result = $conn->query($query);
$dados = $result->fetch_all(MYSQLI_ASSOC);

if ($tipo === 'excel') {
    // Exportar para Excel
    header('Content-Type: application/vnd.ms-excel');
    header('Content-Disposition: attachment; filename="clientes_pendentes_' . date('Y-m-d') . '.xls"');
    
    echo "<table border='1'>";
    echo "<tr><th colspan='6'>Relatório de Clientes com Pagamentos Pendentes</th></tr>";
    echo "<tr><th colspan='6'>Data: " . date('d/m/Y H:i:s') . "</th></tr>";
    echo "<tr><th>Cliente</th><th>CPF/CNPJ</th><th>Contato</th><th>Ordens Pendentes</th><th>Valor Pendente</th><th>Dias Atraso</th></tr>";
    
    $total_geral = 0;
    foreach ($dados as $linha) {
        echo "<tr>";
        echo "<td>" . htmlspecialchars($linha['nome']) . "</td>";
        echo "<td>" . htmlspecialchars($linha['cpf_cnpj']) . "</td>";
        echo "<td>" . htmlspecialchars($linha['telefone']) . "<br>" . htmlspecialchars($linha['email']) . "</td>";
        echo "<td align='center'>" . $linha['total_ordens_pendentes'] . "</td>";
        echo "<td align='right'>R$ " . number_format($linha['total_valor_pendente'], 2, ',', '.') . "</td>";
        echo "<td align='center'>" . $linha['dias_atraso'] . "</td>";
        echo "</tr>";
        
        $total_geral += $linha['total_valor_pendente'];
    }
    
    echo "<tr><td colspan='4' align='right'><strong>TOTAL GERAL:</strong></td>";
    echo "<td align='right'><strong>R$ " . number_format($total_geral, 2, ',', '.') . "</strong></td>";
    echo "<td></td></tr>";
    echo "</table>";
    
} elseif ($tipo === 'pdf') {
    // Para PDF, você precisaria de uma biblioteca como TCPDF ou FPDF
    // Esta é uma implementação básica
    require_once 'tcpdf/tcpdf.php';
    
    $pdf = new TCPDF('L', 'mm', 'A4', true, 'UTF-8');
    $pdf->SetTitle('Clientes Pendentes');
    $pdf->AddPage();
    
    // Adicionar conteúdo ao PDF
    $html = '<h1>Relatório de Clientes com Pagamentos Pendentes</h1>';
    $html .= '<p>Data: ' . date('d/m/Y H:i:s') . '</p>';
    $html .= '<table border="1" cellpadding="5">';
    $html .= '<tr><th>Cliente</th><th>CPF/CNPJ</th><th>Valor Pendente</th><th>Dias Atraso</th></tr>';
    
    foreach ($dados as $linha) {
        $html .= '<tr>';
        $html .= '<td>' . htmlspecialchars($linha['nome']) . '</td>';
        $html .= '<td>' . htmlspecialchars($linha['cpf_cnpj']) . '</td>';
        $html .= '<td>R$ ' . number_format($linha['total_valor_pendente'], 2, ',', '.') . '</td>';
        $html .= '<td>' . $linha['dias_atraso'] . '</td>';
        $html .= '</tr>';
    }
    
    $html .= '</table>';
    
    $pdf->writeHTML($html, true, false, true, false, '');
    $pdf->Output('clientes_pendentes.pdf', 'D');
}

$conn->close();
?>