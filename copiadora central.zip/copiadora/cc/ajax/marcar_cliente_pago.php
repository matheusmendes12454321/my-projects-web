<?php
require_once '../config.php';
verificarLogin();

$conn = conectarBanco();
$cliente_id = $_POST['cliente_id'];

// Atualizar todas as ordens pendentes do cliente
$stmt = $conn->prepare("UPDATE ordens_servico SET status_pagamento = 'pago' WHERE cliente_id = ? AND status_pagamento = 'pendente'");
$stmt->bind_param("i", $cliente_id);

if ($stmt->execute()) {
    registrarLog($_SESSION['usuario_id'], 'pagamento_cliente', "Marcou todas as ordens do cliente #{$cliente_id} como pagas");
    echo json_encode(['success' => true, 'message' => 'Pagamentos registrados']);
} else {
    echo json_encode(['success' => false, 'message' => $conn->error]);
}

$stmt->close();
$conn->close();
?>