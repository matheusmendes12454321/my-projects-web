<?php
// ajax/marcar_pago.php
require_once '../config.php';
verificarLogin();

$conn = conectarBanco();
$ordem_id = $_POST['ordem_id'];

$stmt = $conn->prepare("UPDATE ordens_servico SET status_pagamento = 'pago' WHERE id = ?");
$stmt->bind_param("i", $ordem_id);

if ($stmt->execute()) {
    echo json_encode(['success' => true]);
} else {
    echo json_encode(['success' => false, 'error' => $conn->error]);
}
?>