<?php
require_once '../config.php';
verificarLogin();

$conn = conectarBanco();
$ordem_id = $_POST['ordem_id'];

$stmt = $conn->prepare("UPDATE ordens_servico SET status_pagamento = 'pago' WHERE id = ?");
$stmt->bind_param("i", $ordem_id);

if ($stmt->execute()) {
    registrarLog($_SESSION['usuario_id'], 'pagamento_ordem', "Marcou ordem #{$ordem_id} como paga");
    echo json_encode(['success' => true, 'message' => 'Ordem marcada como paga']);
} else {
    echo json_encode(['success' => false, 'message' => $conn->error]);
}

$stmt->close();
$conn->close();
?>