<?php
// setup_sistema.php - Execute este script UMA vez
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Se já estiver logado, redirecionar
if (isset($_SESSION['usuario_id'])) {
    header('Location: index.php');
    exit();
}

echo "<!DOCTYPE html>
<html>
<head>
    <title>Setup Sistema - Copiadora Central</title>
    <link href='https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css' rel='stylesheet'>
    <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css'>
    <style>
        body { background: #f8f9fa; padding: 20px; }
        .card { margin-bottom: 20px; }
        .success { color: green; }
        .error { color: red; }
        .warning { color: orange; }
    </style>
</head>
<body>
    <div class='container'>
        <div class='row justify-content-center'>
            <div class='col-md-10'>
                <div class='card'>
                    <div class='card-header bg-primary text-white'>
                        <h3 class='mb-0'><i class='fas fa-cogs me-2'></i>Setup do Sistema - Copiadora Central</h3>
                    </div>
                    <div class='card-body'>";

// Conexão básica
$conn = new mysqli('localhost', 'root', '', 'copiadora_central');

if ($conn->connect_error) {
    die("<div class='alert alert-danger'>❌ Erro ao conectar ao banco: " . $conn->connect_error . "</div>");
}

echo "<h4>Passo 1: Verificando Banco de Dados</h4>";

// 1. Criar banco se não existir
$conn->query("CREATE DATABASE IF NOT EXISTS copiadora_central CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
$conn->select_db('copiadora_central');
echo "<p class='success'>✅ Banco de dados verificado</p>";

// 2. Tabelas essenciais
$tabelas = [
    "usuarios" => "CREATE TABLE IF NOT EXISTS usuarios (
        id INT PRIMARY KEY AUTO_INCREMENT,
        nome VARCHAR(100) NOT NULL,
        usuario VARCHAR(50) UNIQUE NOT NULL,
        senha VARCHAR(255) NOT NULL,
        nivel ENUM('admin', 'operador') DEFAULT 'operador',
        ativo BOOLEAN DEFAULT TRUE,
        data_cadastro TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        ultimo_login TIMESTAMP NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
    
    "config" => "CREATE TABLE IF NOT EXISTS config (
        id INT PRIMARY KEY AUTO_INCREMENT,
        chave VARCHAR(50) UNIQUE NOT NULL,
        valor TEXT,
        descricao VARCHAR(200)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
    
    "logs_sistema" => "CREATE TABLE IF NOT EXISTS logs_sistema (
        id INT PRIMARY KEY AUTO_INCREMENT,
        usuario_id INT NULL,
        acao VARCHAR(100),
        descricao TEXT,
        ip VARCHAR(45),
        data_log TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
];

foreach ($tabelas as $nome => $sql) {
    if ($conn->query($sql)) {
        echo "<p class='success'>✅ Tabela <strong>{$nome}</strong> criada/verificada</p>";
    } else {
        echo "<p class='error'>❌ Erro na tabela {$nome}: " . $conn->error . "</p>";
    }
}

echo "<hr><h4>Passo 2: Inserir Dados Essenciais</h4>";

// Inserir configurações
$configs = [
    ['empresa_nome', 'Copiadora Central', 'Nome da empresa'],
    ['empresa_cnpj', '35.885.228/0001-90', 'CNPJ da empresa'],
    ['empresa_endereco', 'Rua Argemiro de Aguilar, 498 - Centro', 'Endereço completo'],
    ['empresa_cidade', 'Almenara - MG', 'Cidade e Estado'],
    ['empresa_telefone', '(33) 99972-1488', 'Telefone principal'],
    ['empresa_email', 'copiadoracentral.almenara@hotmail.com', 'E-mail de contato']
];

foreach ($configs as $config) {
    $stmt = $conn->prepare("INSERT IGNORE INTO config (chave, valor, descricao) VALUES (?, ?, ?)");
    $stmt->bind_param("sss", $config[0], $config[1], $config[2]);
    $stmt->execute();
    echo "<p class='success'>✅ Configuração: {$config[0]}</p>";
}

echo "<hr><h4>Passo 3: Criar Usuários Padrão</h4>";

// Verificar se já existem usuários
$result = $conn->query("SELECT COUNT(*) as total FROM usuarios");
$row = $result->fetch_assoc();

if ($row['total'] == 0) {
    // Criar usuário admin
    $senha_hash = password_hash('admin123', PASSWORD_DEFAULT);
    $stmt = $conn->prepare("INSERT INTO usuarios (nome, usuario, senha, nivel) VALUES (?, ?, ?, ?)");
    $nome = "Administrador";
    $usuario = "admin";
    $nivel = "admin";
    $stmt->bind_param("ssss", $nome, $usuario, $senha_hash, $nivel);
    
    if ($stmt->execute()) {
        echo "<p class='success'>✅ Usuário <strong>admin</strong> criado (senha: admin123)</p>";
    }
    
    // Criar usuário operador
    $senha_hash = password_hash('operador123', PASSWORD_DEFAULT);
    $nome = "Operador";
    $usuario = "operador";
    $nivel = "operador";
    $stmt->bind_param("ssss", $nome, $usuario, $senha_hash, $nivel);
    
    if ($stmt->execute()) {
        echo "<p class='success'>✅ Usuário <strong>operador</strong> criado (senha: operador123)</p>";
    }
} else {
    echo "<p class='warning'>⚠️ Usuários já existem no sistema</p>";
}

echo "<hr><h4>Passo 4: Verificação Final</h4>";

// Verificar todas as tabelas
$result = $conn->query("SHOW TABLES");
echo "<p>Tabelas encontradas (" . $result->num_rows . "):</p>";
echo "<ul>";
while ($row = $result->fetch_array()) {
    echo "<li>{$row[0]}</li>";
}
echo "</ul>";

echo "<hr>";
echo "<div class='alert alert-success'>";
echo "<h4><i class='fas fa-check-circle me-2'></i>Setup Concluído com Sucesso!</h4>";
echo "<p>O sistema está pronto para uso.</p>";
echo "<p><strong>Credenciais para login:</strong></p>";
echo "<ul>";
echo "<li><strong>Administrador:</strong> admin / admin123</li>";
echo "<li><strong>Operador:</strong> operador / operador123</li>";
echo "</ul>";
echo "<a href='login.php' class='btn btn-success btn-lg'>";
echo "<i class='fas fa-sign-in-alt me-2'></i>Ir para Login";
echo "</a>";
echo "</div>";

$conn->close();

echo "</div></div></div></div></body></html>";
?>