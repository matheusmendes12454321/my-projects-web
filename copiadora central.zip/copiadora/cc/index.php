<?php
// index.php
require_once 'config.php';
verificarLogin();

$conn = conectarBanco();

$total_orcamentos = $conn->query("SELECT COUNT(*) as total FROM orcamentos")->fetch_assoc()['total'];
$orcamentos_pendentes = $conn->query("SELECT COUNT(*) as total FROM orcamentos WHERE status = 'pendente'")->fetch_assoc()['total'];
$orcamentos_aprovados = $conn->query("SELECT COUNT(*) as total FROM orcamentos WHERE status = 'aprovado'")->fetch_assoc()['total'];
$valor_orcamentos_pendentes = $conn->query("SELECT SUM(valor_total) as total FROM orcamentos WHERE status = 'pendente'")->fetch_assoc()['total'];
$valor_orcamentos_pendentes = $valor_orcamentos_pendentes ?: 0;
$total_clientes = $conn->query("SELECT COUNT(*) as total FROM clientes")->fetch_assoc()['total'];
$total_servicos = $conn->query("SELECT COUNT(*) as total FROM servicos WHERE ativo = 1")->fetch_assoc()['total'];
$total_pendentes = $conn->query("SELECT COUNT(*) as total FROM ordens_servico WHERE status_pagamento = 'pendente'")->fetch_assoc()['total'];
$total_pagos = $conn->query("SELECT SUM(valor_final) as total FROM ordens_servico WHERE status_pagamento = 'pago'")->fetch_assoc()['total'];
$total_pagos = $total_pagos ?: 0;

// Gastos do mês
$mes_atual = date('Y-m');
$gastos_copiadora = $conn->query("SELECT SUM(valor) as total FROM gastos WHERE tipo = 'copiadora' AND DATE_FORMAT(data_gasto, '%Y-%m') = '$mes_atual'")->fetch_assoc()['total'];
$gastos_savio = $conn->query("SELECT SUM(valor) as total FROM gastos WHERE tipo = 'savio' AND DATE_FORMAT(data_gasto, '%Y-%m') = '$mes_atual'")->fetch_assoc()['total'];
$gastos_copiadora = $gastos_copiadora ?: 0;
$gastos_savio = $gastos_savio ?: 0;
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - Copiadora Central</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css">
    <style>
        .sidebar {
            min-height: 100vh;
            background: linear-gradient(180deg, #2c3e50 0%, #34495e 100%);
        }
        .sidebar .nav-link {
            color: #ecf0f1;
            padding: 15px 20px;
            border-radius: 5px;
            margin: 2px 0;
        }
        .sidebar .nav-link:hover {
            background: rgba(255,255,255,0.1);
        }
        .sidebar .nav-link.active {
            background: #3498db;
        }
        .card-stat {
            border-radius: 10px;
            transition: transform 0.3s;
        }
        .card-stat:hover {
            transform: translateY(-5px);
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-2 p-0 sidebar">
                <div class="p-3">
                    <h4 class="text-white text-center">Copiadora Central</h4>
                    <hr class="text-white">
                </div>
                <nav class="nav flex-column">
                    <a class="nav-link active" href="index.php">
                        <i class="bi bi-speedometer2 me-2"></i> Dashboard
                    </a>
                    <a class="nav-link" href="clientes.php">
                        <i class="bi bi-people me-2"></i> Clientes
                    </a>
                    <a class="nav-link" href="servicos.php">
                        <i class="bi bi-list-task me-2"></i> Serviços
                    </a>
                    <a class="nav-link" href="ordens.php">
                        <i class="bi bi-receipt me-2"></i> Ordens de Serviço
                    </a>
                    <a class="nav-link" href="notas.php">
                        <i class="bi bi-file-text me-2"></i> Notas
                    </a>
                    <a class="nav-link" href="gastos.php">
                        <i class="bi bi-cash-coin me-2"></i> Controle de Gastos
                    </a>
                    <a class="nav-link" href="relatorios.php">
                        <i class="bi bi-graph-up me-2"></i> Relatórios
                    </a>
                    <hr class="text-white">
                    <a class="nav-link" href="logout.php">
                        <i class="bi bi-box-arrow-right me-2"></i> Sair
                    </a>
                </nav>
            </div>

            <!-- Conteúdo Principal -->
            <div class="col-md-10 p-4">
                <h2>Dashboard</h2>
                <p class="text-muted">Bem-vindo ao sistema da Copiadora Central</p>
                
                <div class="row mt-4">
                    <div class="col-md-3">
                        <div class="card card-stat bg-primary text-white">
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-center">
                                    <div>
                                        <h6 class="card-title">Total Clientes</h6>
                                        <h3><?php echo $total_clientes; ?></h3>
                                    </div>
                                    <i class="bi bi-people fs-1"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-md-3">
                        <div class="card card-stat bg-success text-white">
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-center">
                                    <div>
                                        <h6 class="card-title">Serviços Ativos</h6>
                                        <h3><?php echo $total_servicos; ?></h3>
                                    </div>
                                    <i class="bi bi-list-task fs-1"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-md-3">
                        <div class="card card-stat bg-warning text-white">
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-center">
                                    <div>
                                        <h6 class="card-title">Pag. Pendentes</h6>
                                        <h3><?php echo $total_pendentes; ?></h3>
                                    </div>
                                    <i class="bi bi-clock fs-1"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-md-3">
                        <div class="card card-stat bg-info text-white">
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-center">
                                    <div>
                                        <h6 class="card-title">Total Recebido</h6>
                                        <h3><?php echo formatarMoeda($total_pagos); ?></h3>
                                    </div>
                                    <i class="bi bi-cash fs-1"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="row mt-4">
                    <div class="col-md-6">
                        <div class="card">
                            <div class="card-header">
                                <h5>Gastos do Mês</h5>
                            </div>
                            <div class="card-body">
                                <div class="mb-3">
                                    <h6>Copiadora: <span class="text-danger"><?php echo formatarMoeda($gastos_copiadora); ?></span></h6>
                                    <div class="progress">
                                        <div class="progress-bar bg-danger" style="width: <?php echo min(100, ($gastos_copiadora/$total_pagos)*100); ?>%"></div>
                                    </div>
                                </div>
                                <div>
                                    <h6>Savio: <span class="text-warning"><?php echo formatarMoeda($gastos_savio); ?></span></h6>
                                    <div class="progress">
                                        <div class="progress-bar bg-warning" style="width: <?php echo min(100, ($gastos_savio/$total_pagos)*100); ?>%"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-3">
    <div class="card card-stat bg-info text-white">
        <div class="card-body">
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <h6 class="card-title">Orçamentos</h6>
                    <h3><?php echo $total_orcamentos; ?></h3>
                    <small>Pendentes: <?php echo $orcamentos_pendentes; ?> (<?php echo formatarMoeda($valor_orcamentos_pendentes); ?>)</small>
                </div>
                <i class="bi bi-calculator fs-1"></i>
            </div>
        </div>
    </div>
</div>
                    
                    <div class="col-md-6">
                        <div class="card">
                            <div class="card-header">
                                <h5>Ações Rápidas</h5>
                            </div>
                            <div class="card-body">
                                <div class="d-grid gap-2">
                                    <a href="ordens.php?acao=nova" class="btn btn-primary">
                                        <i class="bi bi-plus-circle me-2"></i> Nova Ordem
                                    </a>
                                    <a href="clientes.php?acao=novo" class="btn btn-success">
                                        <i class="bi bi-person-plus me-2"></i> Novo Cliente
                                    </a>
                                    <a href="gastos.php?acao=novo" class="btn btn-warning">
                                        <i class="bi bi-cash-stack me-2"></i> Registrar Gasto
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>