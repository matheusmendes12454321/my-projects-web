<?php
// criar_tabelas_faltantes.php
require_once 'config.php';

$conn = conectarBanco();

echo "<h2>Criando Tabelas Faltantes</h2>";

// SQL para criar tabelas
$sql_tabelas = [
    "logs_sistema" => "CREATE TABLE IF NOT EXISTS logs_sistema (
        id INT PRIMARY KEY AUTO_INCREMENT,
        usuario_id INT NULL,
        acao VARCHAR(100),
        descricao TEXT,
        ip VARCHAR(45),
        data_log TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
    
    "config" => "CREATE TABLE IF NOT EXISTS config (
        id INT PRIMARY KEY AUTO_INCREMENT,
        chave VARCHAR(50) UNIQUE NOT NULL,
        valor TEXT,
        descricao VARCHAR(200)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
    
    "usuarios" => "CREATE TABLE IF NOT EXISTS usuarios (
        id INT PRIMARY KEY AUTO_INCREMENT,
        nome VARCHAR(100) NOT NULL,
        usuario VARCHAR(50) UNIQUE NOT NULL,
        senha VARCHAR(255) NOT NULL,
        nivel ENUM('admin', 'operador') DEFAULT 'operador',
        ativo BOOLEAN DEFAULT TRUE,
        data_cadastro TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        ultimo_login TIMESTAMP NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
];

foreach ($sql_tabelas as $tabela => $sql) {
    if ($conn->query($sql)) {
        echo "<p style='color: green;'>✅ Tabela <strong>{$tabela}</strong> criada/verificada</p>";
    } else {
        echo "<p style='color: red;'>❌ Erro ao criar tabela {$tabela}: " . $conn->error . "</p>";
    }
}

echo "<hr>";
echo "<h3>Verificando todas as tabelas do sistema:</h3>";

$result = $conn->query("SHOW TABLES");
$tabelas_existentes = [];
while ($row = $result->fetch_array()) {
    $tabelas_existentes[] = $row[0];
    echo "<p>📊 {$row[0]}</p>";
}

echo "<hr>";
echo "<p><a href='login.php'>➡️ Voltar para Login</a></p>";

$conn->close();
?>